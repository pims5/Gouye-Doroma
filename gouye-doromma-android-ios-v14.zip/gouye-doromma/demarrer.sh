#!/usr/bin/env bash
# Lancement de test (Codespaces ou terminal) : bash demarrer.sh
set -e
if [ ! -f .env ]; then cp .env.example .env; echo ">> Fichier .env créé : remplissez-le avec les clés Supabase, puis relancez."; exit 0; fi
npm install
npx expo install --fix
npx expo start --tunnel
