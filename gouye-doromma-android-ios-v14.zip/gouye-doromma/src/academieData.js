// Contenu pédagogique : information et formation, jamais de conseil en investissement. Textes à relire par la conformité.
export const MODULES = [
  { id: 'action', icone: '🌱', titre: 'Première action', resume: 'Comprendre ce que vous achetez.', lecons: [
    { id: 'action-1', titre: "Qu'est-ce qu'une action ?", texte: "Acheter une action, c'est devenir copropriétaire d'une petite part d'une entreprise. Si l'entreprise réussit, la valeur de votre part peut augmenter, et elle peut verser une partie de ses bénéfices." },
    { id: 'action-2', titre: 'Pourquoi le cours bouge ?', texte: "Le cours monte ou descend selon l'offre et la demande : ce que les acheteurs acceptent de payer et ce que les vendeurs acceptent de recevoir. Il peut aussi baisser : investir comporte un risque de perte." } ] },
  { id: 'dividendes', icone: '🍊', titre: 'Dividendes', resume: 'Créer un revenu avec vos actions.', lecons: [
    { id: 'div-1', titre: 'Le dividende, une récolte', texte: "Quand une entreprise gagne de l'argent, elle peut en verser une partie à ses actionnaires. C'est le dividende, exprimé en FCFA par action." },
    { id: 'div-2', titre: 'Le rendement', texte: "Le rendement est le dividende divisé par le cours. Un dividende de 1 500 FCFA pour une action à 25 000 FCFA donne 6 %. Il n'est pas garanti d'une année à l'autre." } ] },
  { id: 'brvm', icone: '📈', titre: 'BRVM', resume: 'Les bases de la bourse régionale.', lecons: [
    { id: 'brvm-1', titre: 'La bourse régionale', texte: "La BRVM est la bourse commune des huit pays de l'UEMOA. On y échange des actions et des obligations." },
    { id: 'brvm-2', titre: 'Passer par une SGI', texte: "Les ordres passent par une société de gestion et d'intermédiation (SGI) agréée, qui tient votre compte titres." } ] },
  { id: 'patrimoine', icone: '🌳', titre: 'Construire son patrimoine', resume: 'Bâtir sur le long terme.', lecons: [
    { id: 'pat-1', titre: 'Le temps est un allié', texte: "Investir régulièrement pendant des années laisse le temps aux gains de s'additionner. Chaque année compte." },
    { id: 'pat-2', titre: 'Répartir', texte: "Ne pas tout placer sur une seule entreprise : répartir sur plusieurs valeurs et plusieurs secteurs réduit l'effet d'une mauvaise surprise." } ] },
  { id: 'risque', icone: '🛡️', titre: 'Gestion du risque', resume: 'Investir avec prudence.', lecons: [
    { id: 'risque-1', titre: 'Ne risquez que ce que vous pouvez perdre', texte: "Investissez seulement l'argent dont vous n'avez pas besoin à court terme, et gardez une épargne de précaution." },
    { id: 'risque-2', titre: 'Informer, pas spéculer', texte: "Un prix qui monte vite n'est pas une promesse. Cette application informe et forme ; elle ne donne pas de conseil en investissement." } ] },
];

export const TOTAL_LECONS = MODULES.reduce((n, m) => n + m.lecons.length, 0);

// faites : { idLecon: true }. Les identifiants inconnus sont ignorés.
export function progression(faites) {
  const ids = new Set(MODULES.flatMap((m) => m.lecons.map((l) => l.id)));
  const fait = Object.keys(faites || {}).filter((k) => faites[k] && ids.has(k)).length;
  return { fait, total: TOTAL_LECONS };
}
export const progressionModule = (m, faites) => m.lecons.filter((l) => faites && faites[l.id]).length;
