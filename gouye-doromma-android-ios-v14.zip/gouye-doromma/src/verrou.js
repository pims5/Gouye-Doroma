import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { AppState } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as LocalAuthentication from 'expo-local-authentication';
import { useAuth } from './auth';
import { doitVerrouiller } from './securite';

const Ctx = createContext(null);
export const useVerrou = () => useContext(Ctx);

// Verrou biométrique (Face ID / empreinte, avec le code du téléphone en secours).
// Il protège l'application sur CE téléphone : il n'est pas vérifié par le serveur.
export function VerrouProvider({ children }) {
  const { session, fraiche } = useAuth();
  const uid = session ? session.user.id : null;
  const [actif, setActif] = useState(false);
  const [delai, setDelai] = useState('1min');
  const [verrouille, setVerrouille] = useState(false);
  const fond = useRef(null);

  // Réglages de l'appareil ; verrouillage à l'ouverture si la session a été restaurée (pas juste après un code)
  useEffect(() => {
    if (!uid) { setVerrouille(false); return; }
    let ok = true;
    AsyncStorage.multiGet(['verrou_actif', 'verrou_delai']).then((paires) => {
      if (!ok) return;
      const a = paires[0][1] === '1';
      if (paires[1][1]) setDelai(paires[1][1]);
      setActif(a);
      setVerrouille(a && !fraiche.current);
    });
    return () => { ok = false; };
  }, [uid]); // eslint-disable-line react-hooks/exhaustive-deps

  // Retour au premier plan après un temps en arrière-plan
  useEffect(() => {
    const abo = AppState.addEventListener('change', (etat) => {
      if (etat === 'background') fond.current = Date.now();
      else if (etat === 'active' && fond.current) {
        const ecoule = Date.now() - fond.current;
        fond.current = null;
        if (uid && doitVerrouiller(actif, ecoule, delai)) setVerrouille(true);
      }
    });
    return () => abo.remove();
  }, [actif, delai, uid]);

  const biometrieDisponible = useCallback(async () => {
    try { return (await LocalAuthentication.hasHardwareAsync()) && (await LocalAuthentication.isEnrolledAsync()); }
    catch (e) { return false; }
  }, []);

  const verifier = async (message) => {
    try {
      const r = await LocalAuthentication.authenticateAsync({ promptMessage: message, cancelLabel: 'Annuler' });
      return { ok: !!r.success, erreur: r.success ? null : r.error };
    } catch (e) { return { ok: false, erreur: 'indisponible' }; }
  };

  const deverrouiller = async () => {
    const r = await verifier('Entrer dans votre jardin');
    if (r.ok) setVerrouille(false);
    return r;
  };
  const activerBiometrie = async () => {
    if (!(await biometrieDisponible())) return false;
    const r = await verifier('Activer la protection de votre jardin');
    if (r.ok) { setActif(true); AsyncStorage.setItem('verrou_actif', '1'); }
    return r.ok;
  };
  const desactiver = async () => {
    const r = await verifier('Désactiver la protection');
    if (r.ok) { setActif(false); AsyncStorage.setItem('verrou_actif', '0'); }
    return r.ok;
  };
  const regler = (id) => { setDelai(id); AsyncStorage.setItem('verrou_delai', id); };

  return (
    <Ctx.Provider value={{ actif, delai, verrouille, deverrouiller, activerBiometrie, desactiver, regler, biometrieDisponible }}>
      {children}
    </Ctx.Provider>
  );
}
