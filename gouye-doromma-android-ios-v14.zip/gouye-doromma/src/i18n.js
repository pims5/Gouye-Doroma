import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import fr from './locales/fr.json';
import en from './locales/en.json';
import { traduire } from './traduction';

const DICO = { fr, en };
export const LANGUES = [{ id: 'fr', label: 'Français' }, { id: 'en', label: 'English' }];

const Ctx = createContext(null);
export const useT = () => useContext(Ctx);

// Français par défaut ; l'anglais se choisit dans Profil (traduction en cours : voir README).
export function I18nProvider({ children }) {
  const [langue, setLangue] = useState('fr');
  useEffect(() => { AsyncStorage.getItem('langue').then((v) => { if (v === 'fr' || v === 'en') setLangue(v); }); }, []);
  const choisir = (id) => { setLangue(id); AsyncStorage.setItem('langue', id); };
  const t = (cle, vars) => traduire(DICO, langue, cle, vars);
  return <Ctx.Provider value={{ t, langue, choisir }}>{children}</Ctx.Provider>;
}
