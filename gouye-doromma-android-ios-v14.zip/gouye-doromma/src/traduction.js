// Traduction pure (sans dépendance) : la clé est cherchée dans la langue choisie, puis en français, puis renvoyée telle quelle.
export function traduire(dico, langue, cle, vars) {
  let s = (dico[langue] && dico[langue][cle]) || (dico.fr && dico.fr[cle]) || cle;
  if (vars) for (const k of Object.keys(vars)) s = s.split('{' + k + '}').join(String(vars[k]));
  return s;
}
