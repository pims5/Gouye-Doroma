import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from './auth';
import { progression } from './academieData';

const Ctx = createContext(null);
export const useAcademie = () => useContext(Ctx);

// Leçons terminées, mémorisées par compte sur ce téléphone.
export function AcademieProvider({ children }) {
  const { session } = useAuth();
  const uid = session ? session.user.id : null;
  const [faites, setFaites] = useState({});

  useEffect(() => {
    setFaites({});
    if (!uid) return;
    let ok = true;
    AsyncStorage.getItem('academie_' + uid).then((v) => {
      if (!ok || !v) return;
      try { setFaites(JSON.parse(v)); } catch (e) { /* données illisibles : on repart de zéro */ }
    });
    return () => { ok = false; };
  }, [uid]);

  const terminer = (id) => {
    const n = { ...faites, [id]: true };
    setFaites(n);
    if (uid) AsyncStorage.setItem('academie_' + uid, JSON.stringify(n));
  };
  return <Ctx.Provider value={{ faites, terminer, ...progression(faites) }}>{children}</Ctx.Provider>;
}
