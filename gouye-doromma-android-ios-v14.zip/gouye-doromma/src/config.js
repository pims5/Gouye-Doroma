// Canal d'envoi du code : « sms » (par défaut) ou « whatsapp » (Twilio uniquement, WhatsApp Business à valider).
export const CANAL_PAR_DEFAUT = process.env.EXPO_PUBLIC_CANAL_CODE === 'whatsapp' ? 'whatsapp' : 'sms';
// Mettre EXPO_PUBLIC_WHATSAPP=1 pour proposer à l'utilisateur de recevoir le code par l'autre canal.
export const WHATSAPP_DISPONIBLE = process.env.EXPO_PUBLIC_WHATSAPP === '1';
