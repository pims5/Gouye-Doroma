// Règles de sécurité et de saisie pures (testables sans téléphone).
export const LONGUEUR_CODE = 6;
export const MAX_ECHECS = 3; // après 3 échecs biométriques : retour au code reçu par message

export const DELAIS = [
  { id: 'immediat', label: 'Immédiat', ms: 0 },
  { id: '1min', label: '1 minute', ms: 60000 },
  { id: '5min', label: '5 minutes', ms: 300000 },
];
export const delaiMs = (id) => (DELAIS.find((d) => d.id === id) || DELAIS[1]).ms;
// On reverrouille si la protection est active et que l'application est restée en arrière-plan assez longtemps.
export const doitVerrouiller = (actif, ecouleMs, id) => !!actif && ecouleMs >= delaiMs(id);

export const chiffres = (s) => String(s || '').replace(/\D/g, '');
export const nettoyerCode = (t) => chiffres(t).slice(0, LONGUEUR_CODE);

// Pays de l'UEMOA. Longueurs de numéros à faire confirmer avant le lancement (plans de numérotation susceptibles d'évoluer).
export const PAYS = [
  { id: 'SN', nom: 'Sénégal', indicatif: '221', longueurs: [9], regle: /^7[05678]/ },
  { id: 'ML', nom: 'Mali', indicatif: '223', longueurs: [8] },
  { id: 'CI', nom: "Côte d'Ivoire", indicatif: '225', longueurs: [10] },
  { id: 'BF', nom: 'Burkina Faso', indicatif: '226', longueurs: [8] },
  { id: 'BJ', nom: 'Bénin', indicatif: '229', longueurs: [8, 10] },
  { id: 'TG', nom: 'Togo', indicatif: '228', longueurs: [8] },
  { id: 'NE', nom: 'Niger', indicatif: '227', longueurs: [8] },
  { id: 'GW', nom: 'Guinée-Bissau', indicatif: '245', longueurs: [9] },
];
export const drapeau = (id) => id.replace(/./g, (ch) => String.fromCodePoint(127397 + ch.charCodeAt(0)));
export const longueurMax = (pays) => Math.max(...pays.longueurs);

// Saisie -> { ok, local, e164 }. Accepte aussi +221..., 00221... et 221... collé en entier.
export function normaliserTelephone(saisie, pays) {
  let d = chiffres(saisie);
  const brut = String(saisie || '').trim();
  if (d.startsWith('00' + pays.indicatif)) d = d.slice(2 + pays.indicatif.length);
  else if (brut.startsWith('+') && d.startsWith(pays.indicatif)) d = d.slice(pays.indicatif.length);
  else if (d.length === pays.indicatif.length + longueurMax(pays) && d.startsWith(pays.indicatif)) d = d.slice(pays.indicatif.length);
  const ok = pays.longueurs.includes(d.length) && (!pays.regle || pays.regle.test(d));
  return { ok, local: d, e164: '+' + pays.indicatif + d };
}

// Affichage progressif : 77 123 45 67 (Sénégal), sinon par groupes de 2.
export function formaterLocal(local, pays) {
  const d = chiffres(local);
  const motif = pays && pays.id === 'SN' ? [2, 3, 2, 2] : [2, 2, 2, 2, 2];
  const out = [];
  let i = 0;
  for (const n of motif) { if (i >= d.length) break; out.push(d.slice(i, i + n)); i += n; }
  return out.join(' ');
}
export const masquerTelephone = (local, pays) => '+' + pays.indicatif + ' ' + chiffres(local).slice(0, 2) + ' ••• •• ' + chiffres(local).slice(-2);

// Identifiant affiché dans Profil : numéro formaté (Supabase le stocke sans « + »), sinon l'email d'un ancien compte.
export function afficherTelephone(user) {
  if (!user) return '';
  const d = chiffres(user.phone);
  if (!d) return user.email || '';
  const pays = PAYS.find((p) => d.startsWith(p.indicatif));
  return pays ? '+' + pays.indicatif + ' ' + formaterLocal(d.slice(pays.indicatif.length), pays) : '+' + d;
}
