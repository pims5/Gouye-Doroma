import { formaterMontant } from './devises';

// Phrases explicatives générées uniquement à partir des données affichées (aucune cause inventée).
const nb = (v, d = 1) => Math.abs(v).toFixed(d).replace('.', ',');

export function phraseAction(a) {
  const debut = a.nom + (a.var >= 0 ? ' monte de ' : ' recule de ') + nb(a.var) + ' %. ';
  if (!(a.dividende > 0)) return debut + "Aucun dividende dans nos données d'exemple.";
  const rendement = (a.dividende / a.prix) * 100;
  return debut + 'Son dividende de ' + formaterMontant(a.dividende, a.devise || 'FCFA') + ' par action représente ' + nb(rendement) + ' % du cours.';
}

export function phraseMarche(indice, actions) {
  if (!indice || !actions || actions.length === 0) return '';
  const haut = actions.reduce((m, a) => (a.var > m.var ? a : m));
  const bas = actions.reduce((m, a) => (a.var < m.var ? a : m));
  let s = indice.code + (indice.var >= 0 ? ' gagne ' : ' perd ') + nb(indice.var, 2) + ' %.';
  if (haut.var > 0) s += ' Plus forte hausse : ' + haut.nom + ' (+' + nb(haut.var) + ' %).';
  if (bas.var < 0) s += ' Plus forte baisse : ' + bas.nom + ' (-' + nb(bas.var) + ' %).';
  return s;
}
