import React, { useState } from 'react';
import { ScrollView, View, Pressable } from 'react-native';
import { useTheme, espace, rayon, typo } from '../theme';
import { MODULES, progressionModule } from '../academieData';
import { useAcademie } from '../academie';
import { useT } from '../i18n';
import Texte from '../ui/Texte';
import Carte from '../ui/Carte';
import Bouton from '../ui/Bouton';
import Disclaimer from '../components/Disclaimer';

// Modules courts, à la manière d'une application d'apprentissage : on ouvre un module, on lit, on valide chaque leçon.
export default function AcademieScreen() {
  const { c } = useTheme();
  const { t } = useT();
  const { faites, terminer, fait, total } = useAcademie();
  const [ouvert, setOuvert] = useState(null);

  return (
    <ScrollView style={{ backgroundColor: c.bg }} contentContainerStyle={{ padding: espace.l, gap: espace.m }}>
      <Texte style={{ color: c.muted }}>{t('academy_sub')}</Texte>
      <Texte style={{ fontWeight: '600' }}>{t('lessons_progress', { done: fait, total })}</Texte>
      {MODULES.map((m) => {
        const n = progressionModule(m, faites);
        const complet = n === m.lecons.length;
        const ouvertM = ouvert === m.id;
        return (
          <Carte key={m.id} style={{ padding: 0, overflow: 'hidden' }}>
            <Pressable accessibilityRole="button" accessibilityState={{ expanded: ouvertM }} onPress={() => setOuvert(ouvertM ? null : m.id)}
              style={{ flexDirection: 'row', alignItems: 'center', gap: espace.m, padding: espace.l }}>
              <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: complet ? c.primary : c.border, alignItems: 'center', justifyContent: 'center' }}>
                <Texte style={{ fontSize: 24 }}>{complet ? '✅' : m.icone}</Texte>
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <Texte style={{ fontWeight: '700' }}>{m.titre}</Texte>
                <Texte style={[typo.petit, { color: c.muted }]}>{m.resume}</Texte>
                <View style={{ height: 6, borderRadius: 3, backgroundColor: c.border, overflow: 'hidden' }}>
                  <View style={{ height: 6, width: (n / m.lecons.length * 100) + '%', backgroundColor: c.accent }} />
                </View>
              </View>
              <Texte style={{ color: c.muted }}>{ouvertM ? '⌃' : '⌄'}</Texte>
            </Pressable>
            {ouvertM && (
              <View style={{ paddingHorizontal: espace.l, paddingBottom: espace.l, gap: espace.m }}>
                {m.lecons.map((l) => (
                  <View key={l.id} style={{ backgroundColor: c.bg, borderRadius: rayon.m, padding: espace.m, gap: espace.s }}>
                    <Texte style={{ fontWeight: '600' }}>{l.titre}</Texte>
                    <Texte style={{ color: c.muted }}>{l.texte}</Texte>
                    <Bouton titre={faites[l.id] ? t('lesson_done') + ' ✓' : t('lesson_mark')} variante={faites[l.id] ? 'secondaire' : 'primaire'}
                      desactive={!!faites[l.id]} onPress={() => terminer(l.id)} />
                  </View>
                ))}
              </View>
            )}
          </Carte>
        );
      })}
      <Disclaimer />
    </ScrollView>
  );
}
