import React, { useMemo } from 'react';
import { ScrollView, View, Pressable } from 'react-native';
import { useTheme, fcfa, espace, typo } from '../theme';
import { ACTIONS } from '../data';
import { useStore } from '../store';
import { useAuth } from '../auth';
import { useOrdre } from '../ordre';
import { useT } from '../i18n';
import { useAcademie } from '../academie';
import { resumeJardin, progresPatrimoine } from '../jardin';
import AnneauxPatrimoine from '../components/AnneauxPatrimoine';
import Logo from '../components/Logo';
import Disclaimer from '../components/Disclaimer';
import Signature from '../components/Signature';
import Texte from '../ui/Texte';
import Carte from '../ui/Carte';
import Bouton from '../ui/Bouton';
import Variation from '../ui/Variation';

export default function JardinScreen({ navigation }) {
  const { c } = useTheme();
  const { t } = useT();
  const { cash, lots, positions } = useStore();
  const { prenom } = useAuth();
  const { ouvrirOrdre } = useOrdre();
  const { fait, total: nbLecons } = useAcademie();
  const r = useMemo(() => resumeJardin(lots, cash), [lots, cash]);
  const p = progresPatrimoine(r, nbLecons ? fait / nbLecons : 0);
  const detenus = ACTIONS.filter((a) => positions[a.ticker] > 0);
  const pc = (v) => (v >= 0 ? '+' : '') + v.toFixed(1).replace('.', ',') + ' %';
  const legende = [
    { cle: 'capital', couleur: c.primary, valeur: Math.round(p.capital * 100) + ' %' },
    { cle: 'growth', couleur: c.vert300, valeur: pc(r.gainPct) },
    { cle: 'harvest_ring', couleur: c.accent, valeur: p.rendement.toFixed(1).replace('.', ',') + ' %' },
    { cle: 'knowledge', couleur: c.navy, valeur: fait + '/' + nbLecons },
  ];

  return (
    <ScrollView style={{ backgroundColor: c.bg }} contentContainerStyle={{ padding: espace.l, paddingTop: 56, gap: espace.m }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: espace.m }}>
        <Logo taille={38} />
        <View style={{ flex: 1 }}>
          <Texte style={typo.titre}>{prenom ? t('greeting', { name: prenom }) : t('greeting_anon')}</Texte>
          <Texte style={[typo.petit, { color: c.muted }]}>{t('year_counts')}</Texte>
        </View>
      </View>

      <Carte style={{ alignItems: 'center', gap: espace.m, paddingVertical: espace.xl }}>
        <AnneauxPatrimoine progres={p} total={r.total} taille="L" />
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: espace.s }}>
          <Variation valeur={r.gainPct} taille={15} />
          <Texte style={[typo.petit, { color: c.muted }]}>{t('since_planting')}</Texte>
        </View>
        <View style={{ alignSelf: 'stretch', gap: espace.s }}>
          {legende.map((l) => (
            <View key={l.cle} style={{ flexDirection: 'row', alignItems: 'center', gap: espace.s }}>
              <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: l.couleur }} />
              <Texte style={{ flex: 1, color: c.muted }}>{t(l.cle)}</Texte>
              <Texte style={{ fontWeight: '600', fontVariant: ['tabular-nums'] }}>{l.valeur}</Texte>
            </View>
          ))}
        </View>
        <Texte style={[typo.petit, { color: c.muted }]}>{t('ring_help')}</Texte>
      </Carte>

      <View style={{ flexDirection: 'row', gap: espace.m }}>
        <Bouton titre={t('plant')} style={{ flex: 1 }} onPress={() => ouvrirOrdre({ mode: 'planter' })} />
        <Bouton titre={t('harvest')} variante="recolte" style={{ flex: 1 }} onPress={() => navigation.navigate('Récoltes')} />
      </View>

      <View style={{ flexDirection: 'row', gap: espace.m }}>
        <Carte style={{ flex: 1, padding: espace.m }}>
          <Texte style={[typo.petit, { color: c.muted }]}>{t('cash')}</Texte>
          <Texte style={{ fontWeight: '700', fontVariant: ['tabular-nums'] }}>{fcfa(cash)}</Texte>
        </Carte>
        <Carte style={{ flex: 1, padding: espace.m }}>
          <Texte style={[typo.petit, { color: c.muted }]}>{t('harvest_estimated')}</Texte>
          <Texte style={{ fontWeight: '700', fontVariant: ['tabular-nums'] }}>{fcfa(r.dividendesAn)}</Texte>
        </Carte>
      </View>

      {detenus.length > 0 && (
        <Carte style={{ padding: 0 }}>
          {detenus.map((a, i) => (
            <View key={a.ticker} style={{ flexDirection: 'row', alignItems: 'center', borderTopWidth: i ? 1 : 0, borderTopColor: c.border }}>
              <Pressable accessibilityRole="button" accessibilityLabel={a.nom + ', ' + positions[a.ticker]}
                onPress={() => navigation.navigate('Marchés', { screen: 'Fiche', params: { ticker: a.ticker } })}
                style={{ flex: 1, padding: espace.l }}>
                <Texte style={{ fontWeight: '700' }}>{a.arbre || a.ticker}</Texte>
                <Texte style={[typo.petit, { color: c.muted }]}>{positions[a.ticker]} · {fcfa(positions[a.ticker] * a.prix)}</Texte>
              </Pressable>
              <Pressable accessibilityRole="button" onPress={() => ouvrirOrdre({ mode: 'vendre', ticker: a.ticker })} style={{ padding: espace.l }}>
                <Texte style={{ color: c.primary, fontWeight: '600' }}>{t('sell')}</Texte>
              </Pressable>
            </View>
          ))}
        </Carte>
      )}

      <Pressable accessibilityRole="button" onPress={() => navigation.navigate('Investir')}>
        <Carte style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <View style={{ flex: 1 }}>
            <Texte style={{ fontWeight: '600' }}>Investir pour de vrai</Texte>
            <Texte style={[typo.petit, { color: c.muted }]}>Ce qu'il faudra, et quand. Bientôt disponible.</Texte>
          </View>
          <Texte style={{ color: c.or, fontSize: 22 }}>›</Texte>
        </Carte>
      </Pressable>
      <Disclaimer />
      <Signature />
    </ScrollView>
  );
}
