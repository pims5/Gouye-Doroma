import React from 'react';
import { ScrollView, View } from 'react-native';
import { useTheme, fcfa, espace, typo } from '../theme';
import { ACTIONS } from '../data';
import { useStore } from '../store';
import { useOrdre } from '../ordre';
import { useT } from '../i18n';
import Texte from '../ui/Texte';
import Carte from '../ui/Carte';
import EtatVide from '../ui/EtatVide';
import Disclaimer from '../components/Disclaimer';

// Les dividendes présentés comme des récoltes. Estimation annuelle : les dates de versement réelles viendront avec les données sous licence.
export default function RecoltesScreen() {
  const { c } = useTheme();
  const { t } = useT();
  const { positions } = useStore();
  const { ouvrirOrdre } = useOrdre();
  const arbres = ACTIONS.filter((a) => positions[a.ticker] > 0 && a.dividende > 0)
    .map((a) => ({ a, montant: positions[a.ticker] * a.dividende }))
    .sort((x, y) => y.montant - x.montant);
  const total = arbres.reduce((s, x) => s + x.montant, 0);

  return (
    <ScrollView style={{ backgroundColor: c.bg }} contentContainerStyle={{ padding: espace.l, gap: espace.m }}>
      <Texte style={{ color: c.muted }}>{t('harvests_sub')}</Texte>
      {arbres.length === 0 ? (
        <Carte>
          <EtatVide icone="nutrition-outline" titre={t('harvest_empty_title')} texte={t('harvest_empty_text')}
            actionTitre={t('plant')} onAction={() => ouvrirOrdre({ mode: 'planter' })} />
        </Carte>
      ) : (
        <>
          <Carte style={{ borderColor: c.accent, borderWidth: 2, gap: espace.xs }}>
            <Texte style={[typo.petit, { color: c.muted }]}>{'🍊 ' + t('harvest_estimated')}</Texte>
            <Texte style={[typo.h2, { fontVariant: ['tabular-nums'] }]}>{fcfa(total)}</Texte>
            <Texte style={[typo.petit, { color: c.muted }]}>{t('harvest_note')}</Texte>
          </Carte>
          {arbres.map(({ a, montant }) => (
            <Carte key={a.ticker} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderLeftWidth: 4, borderLeftColor: c.accent }}>
              <View style={{ flex: 1 }}>
                <Texte style={{ fontWeight: '700' }}>{a.arbre || a.nom}</Texte>
                <Texte style={[typo.petit, { color: c.muted }]}>{positions[a.ticker]} × {fcfa(a.dividende)}</Texte>
              </View>
              <Texte style={{ fontWeight: '700', color: c.accent, fontVariant: ['tabular-nums'] }}>+{fcfa(montant)}</Texte>
            </Carte>
          ))}
        </>
      )}
      <Carte style={{ gap: espace.xs }}>
        <Texte style={{ fontWeight: '600' }}>{t('harvest_history')}</Texte>
        <Texte style={{ color: c.muted }}>{t('harvest_history_empty')}</Texte>
      </Carte>
      <Disclaimer />
    </ScrollView>
  );
}
