import React from 'react';
import { ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, police, espace } from '../theme';
import Texte from '../ui/Texte';
import Carte from '../ui/Carte';

const ETAPES = [
  { fait: true, titre: 'Votre numéro de téléphone', detail: 'Déjà fait. Il suffit pour le jardin fictif.' },
  { titre: 'Qui êtes-vous ?', detail: 'Nom, prénom, date de naissance et pays de résidence, avant votre premier placement réel.' },
  { titre: 'Votre portefeuille mobile money', detail: 'Wave, Orange Money ou Free Money, pour déposer et retirer. Souvent le même numéro que celui de votre connexion.' },
  { titre: "Pièce d'identité", detail: 'Seulement si vos montants dépassent le palier fixé avec la conformité.' },
];

// Information seulement : aucune donnée personnelle n'est collectée tant que le placement réel n'est pas ouvert.
export default function InvestirScreen() {
  const { c } = useTheme();
  return (
    <ScrollView style={{ backgroundColor: c.bg }} contentContainerStyle={{ padding: espace.l, gap: espace.m }}>
      <Texte style={{ fontFamily: police.marque, fontSize: 26, lineHeight: 32 }}>Investir pour de vrai.</Texte>
      <Texte style={{ color: c.muted }}>Nous ne demandons que ce qui est nécessaire, au moment où c'est nécessaire.</Texte>
      <Carte style={{ padding: 0 }}>
        {ETAPES.map((e, i) => (
          <View key={e.titre} style={{ flexDirection: 'row', gap: espace.m, padding: espace.l, borderTopWidth: i ? 1 : 0, borderTopColor: c.border }}>
            <Ionicons name={e.fait ? 'checkmark-circle' : 'ellipse-outline'} size={22} color={e.fait ? c.primary : c.or} />
            <View style={{ flex: 1 }}>
              <Texte style={{ fontWeight: '600' }}>{e.titre}</Texte>
              <Texte style={{ color: c.muted, fontSize: 13 }}>{e.detail}</Texte>
            </View>
          </View>
        ))}
      </Carte>
      <Carte style={{ gap: espace.xs }}>
        <Texte style={{ fontWeight: '600' }}>Chaque ordre réel</Texte>
        <Texte style={{ color: c.muted }}>Sera confirmé par Face ID ou l'empreinte.</Texte>
      </Carte>
      <Carte style={{ gap: espace.xs }}>
        <Texte style={{ fontWeight: '600' }}>Bientôt disponible</Texte>
        <Texte style={{ color: c.muted }}>
          Cette étape s'ouvrira après l'obtention de la licence de données BRVM et la validation de la conformité.
          Aucune information personnelle n'est demandée pour l'instant.
        </Texte>
      </Carte>
      <Carte style={{ gap: espace.xs }}>
        <Texte style={{ fontWeight: '600' }}>Actions internationales</Texte>
        <Texte style={{ color: c.muted }}>
          Apple, Google, Amazon et d'autres sont déjà présentées dans Marchés, à titre d'information. Leur achat viendra plus tard,
          avec un partenaire autorisé et dans le respect de la réglementation des changes : à valider avec la conformité.
        </Texte>
      </Carte>
    </ScrollView>
  );
}
