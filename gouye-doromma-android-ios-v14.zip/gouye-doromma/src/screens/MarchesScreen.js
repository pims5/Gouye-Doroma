import React, { useCallback, useEffect, useState } from 'react';
import { View, FlatList, TextInput, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, espace, rayon, typo } from '../theme';
import { INDICES, INDICES_INTL, chargerActions } from '../data';
import { useStore } from '../store';
import ActionRow from '../components/ActionRow';
import { phraseMarche } from '../phrases';
import Disclaimer from '../components/Disclaimer';
import Texte from '../ui/Texte';
import Chip from '../ui/Chip';
import EtatVide from '../ui/EtatVide';
import Squelette from '../ui/Squelette';
import Variation from '../ui/Variation';

const FILTRES = [
  { id: 'tous', label: 'Toutes' },
  { id: 'hausse', label: 'En hausse' },
  { id: 'baisse', label: 'En baisse' },
  { id: 'suivies', label: 'Suivies' },
];

export default function MarchesScreen({ navigation }) {
  const { c } = useTheme();
  const { favoris } = useStore();
  const [actions, setActions] = useState(null); // null = chargement
  const [erreur, setErreur] = useState(false);
  const [recherche, setRecherche] = useState('');
  const [filtre, setFiltre] = useState('tous');
  const [rafraichit, setRafraichit] = useState(false);
  const [marche, setMarche] = useState('UEMOA'); // 'UEMOA' | 'INTERNATIONAL'

  const charger = useCallback(async () => {
    setErreur(false);
    try { setActions(await chargerActions()); }
    catch (e) { setErreur(true); setActions([]); }
  }, []);
  useEffect(() => { charger(); }, [charger]);
  const rafraichir = async () => { setRafraichit(true); await charger(); setRafraichit(false); };

  const q = recherche.trim().toLowerCase();
  const duMarche = (actions || []).filter((a) => a.marche === marche);
  const liste = duMarche.filter((a) =>
    (!q || a.ticker.toLowerCase().includes(q) || a.nom.toLowerCase().includes(q)) &&
    (filtre === 'tous' || (filtre === 'hausse' && a.var >= 0) || (filtre === 'baisse' && a.var < 0) ||
      (filtre === 'suivies' && favoris[a.ticker])));

  const [principal, ...autres] = marche === 'UEMOA' ? INDICES : INDICES_INTL;

  const entete = (
    <View style={{ gap: espace.m, marginBottom: espace.m }}>
      <View style={{ flexDirection: 'row', gap: espace.s }}>
        <Chip label="UEMOA" actif={marche === 'UEMOA'} onPress={() => setMarche('UEMOA')} />
        <Chip label="International" actif={marche === 'INTERNATIONAL'} onPress={() => setMarche('INTERNATIONAL')} />
      </View>
      <View style={{ backgroundColor: c.primary, borderRadius: rayon.xl, padding: espace.xl }}>
        <Texte style={[typo.petit, { color: c.surPrimaire }]}>{principal.code} · clôture</Texte>
        <Texte style={[typo.chiffre, { fontSize: 40, lineHeight: 48, color: c.surPrimaire }]}>
          {principal.value.toFixed(2).replace('.', ',')}
        </Texte>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: espace.l, marginTop: espace.xs }}>
          <Variation valeur={principal.var} taille={15} couleur={c.surPrimaire} />
          {autres.map((i) => (
            <Texte key={i.code} style={[typo.petit, { color: c.surPrimaire }]}>
              {i.code} {i.value.toFixed(2).replace('.', ',')}
            </Texte>
          ))}
        </View>
        {duMarche.length > 0 && (
          <Texte style={[typo.corps, { color: c.surPrimaire, marginTop: espace.m }]}>{phraseMarche(principal, duMarche)}</Texte>
        )}
      </View>

      {marche === 'INTERNATIONAL' && (
        <Texte style={[typo.petit, { color: c.muted }]}>
          Cours en dollars, à titre d'information. L'achat sera proposé plus tard, avec un partenaire autorisé.
        </Texte>
      )}

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: espace.s, backgroundColor: c.card,
        borderColor: c.border, borderWidth: 1, borderRadius: rayon.m, paddingHorizontal: espace.m }}>
        <Ionicons name="search" size={18} color={c.muted} />
        <TextInput
          style={{ flex: 1, minHeight: 46, color: c.text, fontSize: 15 }}
          placeholder="Rechercher une action"
          placeholderTextColor={c.muted}
          accessibilityLabel="Rechercher une action"
          value={recherche}
          onChangeText={setRecherche}
          autoCapitalize="none"
          autoCorrect={false}
          returnKeyType="search"
        />
      </View>

      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={FILTRES}
        keyExtractor={(f) => f.id}
        contentContainerStyle={{ gap: espace.s }}
        renderItem={({ item }) => <Chip label={item.label} actif={filtre === item.id} onPress={() => setFiltre(item.id)} />}
      />
    </View>
  );

  const vide = actions === null ? (
    <View style={{ gap: espace.m }}>
      {[0, 1, 2, 3].map((k) => <Squelette key={k} hauteur={68} style={{ borderRadius: rayon.l }} />)}
    </View>
  ) : erreur ? (
    <EtatVide icone="cloud-offline" titre="Données indisponibles"
      texte="Vérifiez votre connexion, puis réessayez." actionTitre="Réessayer" onAction={charger} />
  ) : filtre === 'suivies' && !q ? (
    <EtatVide icone="star-outline" titre="Aucune action suivie"
      texte="Ouvrez la fiche d'une action et touchez « Suivre cette action »." />
  ) : (
    <EtatVide titre="Aucun résultat" texte="Essayez un autre nom ou un autre filtre." />
  );

  return (
    <FlatList
      style={{ backgroundColor: c.bg }}
      contentContainerStyle={{ padding: espace.l, gap: espace.m }}
      keyboardShouldPersistTaps="handled"
      data={actions === null ? [] : liste}
      keyExtractor={(a) => a.ticker}
      ListHeaderComponent={entete}
      ListEmptyComponent={vide}
      renderItem={({ item }) => (
        <ActionRow action={item} onPress={() => navigation.navigate('Fiche', { ticker: item.ticker })} />
      )}
      refreshControl={<RefreshControl refreshing={rafraichit} onRefresh={rafraichir} tintColor={c.primary} />}
      ListFooterComponent={<Disclaimer />}
    />
  );
}
