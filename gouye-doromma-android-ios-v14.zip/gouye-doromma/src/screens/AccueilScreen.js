import React, { useRef, useState, useMemo } from 'react';
import { View, FlatList, TouchableOpacity, useWindowDimensions, StyleSheet } from 'react-native';
import Text from '../ui/Texte';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../theme';

const PAGES = [
  {
    icone: 'stats-chart',
    titre: 'Suivez la BRVM',
    texte: "Cours de clôture, indices et dividendes des actions de l'UEMOA, réunis au même endroit.",
  },
  {
    icone: 'school',
    titre: 'Apprenez sans risque',
    texte: 'Testez vos idées avec un portefeuille fictif de 1 000 000 FCFA. Aucun argent réel n\'est en jeu.',
  },
  {
    icone: 'shield-checkmark',
    titre: "Une application d'information",
    texte: "Elle vous informe et vous forme. Elle ne passe pas d'ordres et ne donne pas de conseil en investissement. Investir comporte un risque de perte en capital.",
  },
];

export default function AccueilScreen({ onTermine }) {
  const { c: colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const { width } = useWindowDimensions();
  const [i, setI] = useState(0);
  const liste = useRef(null);
  const dernier = i === PAGES.length - 1;

  const suivant = () => {
    if (dernier) onTermine();
    else liste.current.scrollToIndex({ index: i + 1 });
  };

  return (
    <View style={s.page}>
      <TouchableOpacity style={s.passer} onPress={onTermine} accessibilityRole="button">
        <Text style={{ color: colors.muted }}>Passer</Text>
      </TouchableOpacity>

      <FlatList
        ref={liste}
        data={PAGES}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(p) => p.titre}
        onMomentumScrollEnd={(e) => setI(Math.round(e.nativeEvent.contentOffset.x / width))}
        renderItem={({ item }) => (
          <View style={[s.slide, { width }]}>
            <View style={s.rond}>
              <Ionicons name={item.icone} size={56} color={colors.primary} />
            </View>
            <Text style={s.titre}>{item.titre}</Text>
            <Text style={s.texte}>{item.texte}</Text>
          </View>
        )}
      />

      <View style={s.points}>
        {PAGES.map((p, k) => (
          <View key={p.titre} style={[s.point, k === i && s.pointActif]} />
        ))}
      </View>

      <TouchableOpacity style={s.btn} onPress={suivant}>
        <Text style={s.btnTxt}>{dernier ? 'Commencer' : 'Suivant'}</Text>
      </TouchableOpacity>
    </View>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  page: { flex: 1, backgroundColor: colors.bg, paddingTop: 60, paddingBottom: 40 },
  passer: { alignSelf: 'flex-end', paddingHorizontal: 20, paddingVertical: 8 },
  slide: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32 },
  rond: { width: 120, height: 120, borderRadius: 60, backgroundColor: colors.card, borderColor: colors.border,
          borderWidth: 1, alignItems: 'center', justifyContent: 'center', marginBottom: 28 },
  titre: { fontSize: 24, fontWeight: '700', color: colors.primary, textAlign: 'center', marginBottom: 12 },
  texte: { fontSize: 16, lineHeight: 23, color: colors.text, textAlign: 'center' },
  points: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginVertical: 20 },
  point: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.border },
  pointActif: { width: 22, backgroundColor: colors.primary },
  btn: { backgroundColor: colors.primary, borderRadius: 10, padding: 14, alignItems: 'center', marginHorizontal: 24 },
  btnTxt: { color: colors.surPrimaire, fontWeight: '600', fontSize: 16 },
});
