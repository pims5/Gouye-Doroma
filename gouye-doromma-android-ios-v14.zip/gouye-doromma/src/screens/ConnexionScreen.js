import React, { useEffect, useRef, useState } from 'react';
import { ScrollView, View, TextInput, Pressable, ActivityIndicator } from 'react-native';
import { useTheme, police, espace } from '../theme';
import { configure } from '../supabase';
import { useAuth } from '../auth';
import { CANAL_PAR_DEFAUT, WHATSAPP_DISPONIBLE } from '../config';
import { PAYS, drapeau, longueurMax, normaliserTelephone, formaterLocal, masquerTelephone, nettoyerCode, LONGUEUR_CODE } from '../securite';
import Texte from '../ui/Texte';
import Bouton from '../ui/Bouton';
import Logo from '../components/Logo';
import AnneauxCode from '../components/AnneauxCode';
import ChoixPays from '../components/ChoixPays';
import Disclaimer from '../components/Disclaimer';

const nomCanal = (k) => (k === 'whatsapp' ? 'WhatsApp' : 'SMS');

// Un seul champ (le numéro), puis un code à 6 chiffres : création de compte et connexion sont le même geste.
export default function ConnexionScreen() {
  const { c } = useTheme();
  const { envoyerCode, verifierCode } = useAuth();
  const [etape, setEtape] = useState('numero'); // 'numero' | 'code'
  const [pays, setPays] = useState(PAYS[0]);
  const [choixPays, setChoixPays] = useState(false);
  const [local, setLocal] = useState('');
  const [canal, setCanal] = useState(CANAL_PAR_DEFAUT);
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState('');
  const [erreur, setErreur] = useState(false);
  const [occupe, setOccupe] = useState(false);
  const [attente, setAttente] = useState(0);
  const saisie = useRef(null);
  const tel = normaliserTelephone(local, pays);

  useEffect(() => {
    if (attente <= 0) return;
    const t = setTimeout(() => setAttente(attente - 1), 1000);
    return () => clearTimeout(t);
  }, [attente]);

  const demander = async (canalChoisi = canal) => {
    if (!tel.ok) { setErreur(true); return setMsg('Entrez un numéro de téléphone valide.'); }
    setCanal(canalChoisi); setOccupe(true); setMsg(''); setErreur(false);
    const r = await envoyerCode(tel.e164, canalChoisi);
    setOccupe(false);
    if (r.erreur) { setErreur(true); return setMsg(r.erreur); }
    setCode(''); setEtape('code'); setAttente(45);
  };

  const changerCode = async (texte) => {
    const d = nettoyerCode(texte);
    setCode(d); setMsg(''); setErreur(false);
    if (d.length < LONGUEUR_CODE) return;
    setOccupe(true);
    const r = await verifierCode(tel.e164, d);
    setOccupe(false);
    if (r.erreur) { setErreur(true); setMsg(r.erreur); setCode(''); }
  };

  const titre = { fontFamily: police.marque, fontSize: 30, lineHeight: 36, textAlign: 'center', marginTop: espace.l };
  const lien = { color: c.primary, fontWeight: '600', textAlign: 'center', padding: espace.m };
  const autre = canal === 'whatsapp' ? 'sms' : 'whatsapp';

  return (
    <ScrollView style={{ backgroundColor: c.bg }} keyboardShouldPersistTaps="handled"
      contentContainerStyle={{ padding: 28, paddingTop: 72, alignItems: 'center', gap: espace.m, flexGrow: 1 }}>
      <Logo taille={72} />

      {!configure && (
        <Texte style={{ backgroundColor: '#fff4e5', color: '#8a5a00', padding: 10, borderRadius: 10 }}>
          Compte non configuré : remplissez le fichier .env avec les clés Supabase (voir README).
        </Texte>
      )}

      {etape === 'numero' ? (
        <>
          <Texte style={titre}>Bienvenue.</Texte>
          <Texte style={{ color: c.muted, textAlign: 'center' }}>
            Votre numéro de téléphone suffit. Nous vous envoyons un code : aucun mot de passe à retenir.
          </Texte>
          <View style={{ alignSelf: 'stretch', marginTop: espace.s }}>
            <Texte style={{ color: c.or, fontSize: 11, letterSpacing: 2, fontWeight: '600' }}>NUMÉRO DE TÉLÉPHONE</Texte>
            <View style={{ flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: c.or }}>
              <Pressable onPress={() => setChoixPays(true)} accessibilityRole="button"
                accessibilityLabel={'Pays : ' + pays.nom + ', indicatif +' + pays.indicatif + '. Changer de pays'}
                style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 10, paddingRight: 12 }}>
                <Texte style={{ fontSize: 20 }}>{drapeau(pays.id)}</Texte>
                <Texte style={{ fontSize: 17 }}>+{pays.indicatif}</Texte>
                <Texte style={{ color: c.muted }}>▾</Texte>
              </Pressable>
              <TextInput
                value={formaterLocal(local, pays)}
                onChangeText={(t) => setLocal(normaliserTelephone(t, pays).local.slice(0, longueurMax(pays)))}
                onSubmitEditing={() => demander()}
                placeholder={pays.id === 'SN' ? '77 123 45 67' : 'Numéro'} placeholderTextColor={c.muted}
                keyboardType="phone-pad" autoComplete="tel" textContentType="telephoneNumber" returnKeyType="go"
                accessibilityLabel="Numéro de téléphone"
                style={{ flex: 1, fontSize: 17, color: c.text, paddingVertical: 10 }}
              />
            </View>
          </View>
          {!!msg && <Texte style={{ color: erreur ? c.down : c.up }} accessibilityLiveRegion="polite">{msg}</Texte>}
          <Bouton titre="Continuer" onPress={() => demander()} chargement={occupe} style={{ alignSelf: 'stretch' }} />
          <Texte style={{ color: c.muted, fontSize: 12, textAlign: 'center' }}>
            Nouveau ou déjà membre : c'est le même geste. Le code arrive par {nomCanal(canal)}.
          </Texte>
        </>
      ) : (
        <>
          <Texte style={titre}>Un code vient d'arriver.</Texte>
          <Texte style={{ color: c.muted, textAlign: 'center' }}>
            Envoyé au {masquerTelephone(tel.local, pays)} par {nomCanal(canal)}. Saisissez-le dans les six anneaux.
          </Texte>
          <View style={{ marginVertical: espace.m }}>
            <AnneauxCode valeur={code} longueur={LONGUEUR_CODE} erreur={erreur} onPress={() => saisie.current && saisie.current.focus()} />
            <TextInput
              ref={saisie} value={code} onChangeText={changerCode} autoFocus editable={!occupe}
              keyboardType="number-pad" maxLength={LONGUEUR_CODE}
              textContentType="oneTimeCode" autoComplete="one-time-code"
              accessibilityLabel="Code à 6 chiffres" caretHidden
              style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, opacity: 0.02, color: 'transparent' }}
            />
          </View>
          {occupe && <ActivityIndicator color={c.primary} />}
          {!!msg && <Texte style={{ color: erreur ? c.down : c.up, textAlign: 'center' }} accessibilityLiveRegion="polite">{msg}</Texte>}
          <Pressable onPress={() => demander()} disabled={attente > 0 || occupe} accessibilityRole="button">
            <Texte style={{ ...lien, opacity: attente > 0 ? 0.5 : 1 }}>
              {attente > 0 ? 'Renvoyer le code dans 0:' + String(attente).padStart(2, '0') : 'Renvoyer le code'}
            </Texte>
          </Pressable>
          {WHATSAPP_DISPONIBLE && attente <= 0 && (
            <Pressable onPress={() => demander(autre)} disabled={occupe} accessibilityRole="button">
              <Texte style={lien}>Recevoir plutôt par {nomCanal(autre)}</Texte>
            </Pressable>
          )}
          <Pressable onPress={() => { setEtape('numero'); setMsg(''); setCode(''); }} accessibilityRole="button">
            <Texte style={[lien, { color: c.muted, fontWeight: '400' }]}>Changer de numéro</Texte>
          </Pressable>
        </>
      )}

      <View style={{ flex: 1 }} />
      <Disclaimer />
      <ChoixPays visible={choixPays} actuel={pays} onFermer={() => setChoixPays(false)}
        onChoisir={(p) => { setPays(p); setLocal(''); setChoixPays(false); }} />
    </ScrollView>
  );
}
