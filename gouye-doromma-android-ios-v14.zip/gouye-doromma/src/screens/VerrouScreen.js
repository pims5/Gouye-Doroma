import React, { useEffect, useState } from 'react';
import { View, Pressable } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { useTheme, police, espace } from '../theme';
import { useAuth } from '../auth';
import { useVerrou } from '../verrou';
import { MAX_ECHECS } from '../securite';
import Texte from '../ui/Texte';
import Logo from '../components/Logo';

// Écran de retour : un seul geste. Après 3 échecs, retour au code par email.
export default function VerrouScreen() {
  const { c } = useTheme();
  const { prenom, deconnecter } = useAuth();
  const { deverrouiller } = useVerrou();
  const [echecs, setEchecs] = useState(0);
  const [occupe, setOccupe] = useState(false);

  const essayer = async () => {
    if (occupe) return;
    setOccupe(true);
    const r = await deverrouiller();
    setOccupe(false);
    if (r.ok) return;
    if (r.erreur === 'authentication_failed' || r.erreur === 'lockout') {
      const k = echecs + 1;
      setEchecs(k);
      if (k >= MAX_ECHECS) deconnecter();
    }
  };
  useEffect(() => { const t = setTimeout(essayer, 400); return () => clearTimeout(t); }, []); // eslint-disable-line

  return (
    <View style={{ flex: 1, backgroundColor: c.bg, alignItems: 'center', justifyContent: 'center', padding: 28, gap: espace.m }}>
      <Logo taille={72} />
      <Texte style={{ fontFamily: police.marque, fontSize: 30, lineHeight: 36, textAlign: 'center' }}>
        {prenom ? 'Bonjour, ' + prenom + '.' : 'Bon retour.'}
      </Texte>
      <Texte style={{ color: c.muted }}>Touchez pour entrer.</Texte>
      <Pressable onPress={essayer} accessibilityRole="button" accessibilityLabel="Déverrouiller avec Face ID, l'empreinte ou le code du téléphone"
        style={{ marginVertical: espace.l }}>
        <Svg width={112} height={112} viewBox="0 0 112 112">
          <Circle cx="56" cy="56" r="52" stroke={c.border} strokeWidth="3" fill="none" />
          <Circle cx="56" cy="56" r="38" stroke={c.or} strokeWidth="3" fill="none" />
          <Circle cx="56" cy="56" r="24" stroke={c.primary} strokeWidth="3" fill="none" />
        </Svg>
      </Pressable>
      {echecs > 0 && <Texte style={{ color: c.down }}>Essai {echecs} sur {MAX_ECHECS}.</Texte>}
      <Pressable onPress={deconnecter} accessibilityRole="button">
        <Texte style={{ color: c.primary, fontWeight: '600', padding: espace.m }}>Utiliser un code par SMS</Texte>
      </Pressable>
    </View>
  );
}
