import React, { useState } from 'react';
import { ScrollView, View, TextInput } from 'react-native';
import { useTheme, police, espace } from '../theme';
import { useAuth } from '../auth';
import { useVerrou } from '../verrou';
import Texte from '../ui/Texte';
import Bouton from '../ui/Bouton';
import Carte from '../ui/Carte';
import Logo from '../components/Logo';

// Après le premier code : prénom (facultatif) et activation de la deuxième clé (Face ID / empreinte).
export default function BienvenueScreen({ onTermine }) {
  const { c } = useTheme();
  const { definirPrenom } = useAuth();
  const { actif, activerBiometrie } = useVerrou();
  const [prenom, setPrenom] = useState('');
  const [msg, setMsg] = useState('');
  const [occupe, setOccupe] = useState(false);

  const activer = async () => {
    setMsg('');
    const ok = await activerBiometrie();
    if (!ok) setMsg("Activation impossible : configurez Face ID ou l'empreinte dans les réglages du téléphone.");
  };
  const entrer = async () => {
    setOccupe(true);
    if (prenom.trim()) await definirPrenom(prenom.trim());
    setOccupe(false);
    onTermine();
  };

  return (
    <ScrollView style={{ backgroundColor: c.bg }} keyboardShouldPersistTaps="handled"
      contentContainerStyle={{ padding: 28, paddingTop: 72, alignItems: 'center', gap: espace.m }}>
      <Logo taille={72} />
      <Texte style={{ fontFamily: police.marque, fontSize: 30, lineHeight: 36, textAlign: 'center' }}>Ravi de vous voir.</Texte>
      <View style={{ alignSelf: 'stretch' }}>
        <Texte style={{ color: c.or, fontSize: 11, letterSpacing: 2, fontWeight: '600' }}>COMMENT DOIT-ON VOUS APPELER ? (FACULTATIF)</Texte>
        <TextInput value={prenom} onChangeText={setPrenom} placeholder="Prénom" placeholderTextColor={c.muted}
          autoCapitalize="words" autoComplete="given-name" textContentType="givenName" accessibilityLabel="Prénom"
          style={{ borderBottomWidth: 1, borderBottomColor: c.or, fontSize: 17, color: c.text, paddingVertical: 10 }} />
      </View>
      <Carte style={{ alignSelf: 'stretch', gap: espace.s }}>
        <Texte style={{ fontFamily: police.marque, fontSize: 17 }}>Entrer en un geste</Texte>
        <Texte style={{ color: c.muted }}>
          Activez Face ID ou l'empreinte : votre visage ou votre doigt deviennent la deuxième clé de votre jardin.
        </Texte>
        <Bouton titre={actif ? 'Activé' : 'Activer'} variante="secondaire" desactive={actif} onPress={activer} />
        {!!msg && <Texte style={{ color: c.down }} accessibilityLiveRegion="polite">{msg}</Texte>}
      </Carte>
      <Bouton titre="Entrer dans mon jardin" onPress={entrer} chargement={occupe} style={{ alignSelf: 'stretch' }} />
    </ScrollView>
  );
}
