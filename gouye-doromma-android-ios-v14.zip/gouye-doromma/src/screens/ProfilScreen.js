import React, { useMemo } from 'react';
import { View, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import Text from '../ui/Texte';
import { useTheme } from '../theme';
import { useAuth } from '../auth';
import Disclaimer from '../components/Disclaimer';
import Chip from '../ui/Chip';
import CarteSecurite from '../components/CarteSecurite';
import { useT, LANGUES } from '../i18n';
import { afficherTelephone } from '../securite';

export default function ProfilScreen() {
  const { c: colors, mode, choisir } = useTheme();
  const { t, langue, choisir: choisirLangue } = useT();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const { session, deconnecter, supprimerCompte } = useAuth();

  const confirmerSuppression = () =>
    Alert.alert(
      'Supprimer mon compte',
      'Votre compte sera supprimé définitivement. Cette action est irréversible.',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer', style: 'destructive',
          onPress: async () => {
            const r = await supprimerCompte();
            if (r.erreur) Alert.alert('Suppression impossible', r.erreur);
          },
        },
      ]
    );

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, padding: 16 }}>
      <View style={s.card}>
        <Text style={{ color: colors.muted }}>Connecté avec</Text>
        <Text style={{ fontWeight: '700', color: colors.text, fontSize: 16 }}>{afficherTelephone(session.user)}</Text>
      </View>
      <View style={s.card}>
        <Text style={{ color: colors.muted, marginBottom: 10 }}>{t('language')}</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {LANGUES.map((l) => <Chip key={l.id} label={l.label} actif={langue === l.id} onPress={() => choisirLangue(l.id)} />)}
        </View>
        {langue === 'en' && <Text style={{ color: colors.muted, fontSize: 12, marginTop: 8 }}>{t('language_partial')}</Text>}
      </View>
      <CarteSecurite />
      <View style={s.card}>
        <Text style={{ color: colors.muted, marginBottom: 10 }}>Apparence</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {[['systeme', 'Système'], ['clair', 'Clair'], ['sombre', 'Sombre']].map(([id, label]) => (
            <Chip key={id} label={label} actif={mode === id} onPress={() => choisir(id)} />
          ))}
        </View>
      </View>
      <TouchableOpacity style={s.btn} onPress={deconnecter}>
        <Text style={{ color: colors.surPrimaire, fontWeight: '600' }}>Se déconnecter</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.btnAlt} onPress={confirmerSuppression}>
        <Text style={{ color: colors.down, fontWeight: '600' }}>Supprimer mon compte</Text>
      </TouchableOpacity>
      <Disclaimer />
    </View>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  card: { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 14 },
  btn: { backgroundColor: colors.primary, borderRadius: 10, padding: 14, alignItems: 'center', marginBottom: 10 },
  btnAlt: { borderColor: colors.down, borderWidth: 1, borderRadius: 10, padding: 14, alignItems: 'center' },
});
