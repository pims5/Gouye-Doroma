import React, { useState, useMemo } from 'react';
import { ScrollView, View, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import Text from '../ui/Texte';
import { useTheme, fcfa } from '../theme';
import { ACTIONS as TOUTES } from '../data';
const ACTIONS = TOUTES.filter((a) => a.simulable); // les valeurs internationales sont en information seulement
import Disclaimer from '../components/Disclaimer';

export default function DividendesScreen({ route }) {
  const { c: colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const depart = ACTIONS.find((x) => x.ticker === (route.params && route.params.ticker)) || ACTIONS[0];
  const [a, setA] = useState(depart);
  const [qte, setQte] = useState('10');
  const [objectif, setObjectif] = useState('100000');

  const n = Math.max(0, parseInt(qte, 10) || 0);
  const obj = Math.max(0, parseInt(objectif, 10) || 0);
  const annuel = n * a.dividende;
  const rendement = (a.dividende / a.prix) * 100;
  const besoin = a.dividende > 0 ? Math.ceil(obj / a.dividende) : 0;

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
      <View style={s.card}>
        <Text style={s.label}>Action</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 8 }}>
          {ACTIONS.map((x) => (
            <TouchableOpacity key={x.ticker} onPress={() => setA(x)}
              style={[s.chip, a.ticker === x.ticker && { backgroundColor: colors.primary }]}>
              <Text style={{ color: a.ticker === x.ticker ? colors.surPrimaire : colors.text }}>{x.ticker}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <Text style={s.label}>Nombre d'actions détenues</Text>
        <TextInput style={s.input} keyboardType="number-pad" value={qte} onChangeText={setQte} />
        <Text style={s.resultatLabel}>Dividendes estimés par an</Text>
        <Text style={s.resultat}>{fcfa(annuel)}</Text>
        <Text style={s.mut}>
          {fcfa(a.dividende)} par action · rendement {rendement.toFixed(1).replace('.', ',')}% du cours actuel
        </Text>
      </View>

      <View style={s.card}>
        <Text style={s.label}>Combien d'actions pour un objectif ?</Text>
        <Text style={s.mut}>Revenu annuel visé (FCFA)</Text>
        <TextInput style={s.input} keyboardType="number-pad" value={objectif} onChangeText={setObjectif} />
        <Text style={{ color: colors.text }}>
          Il faudrait environ <Text style={{ fontWeight: '700' }}>{besoin.toLocaleString('fr-FR')} actions {a.ticker}</Text>,
          soit un investissement d'environ {fcfa(besoin * a.prix)}.
        </Text>
      </View>

      <Text style={[s.mut, { marginTop: 4 }]}>
        Estimation brute, avant impôts et frais, calculée avec le dernier dividende connu. Les dividendes passés ne garantissent pas ceux à venir.
      </Text>
      <Disclaimer />
    </ScrollView>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  card: { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 12 },
  label: { fontWeight: '700', color: colors.text },
  mut: { color: colors.muted, fontSize: 13 },
  chip: { borderColor: colors.border, borderWidth: 1, borderRadius: 20, paddingVertical: 8, paddingHorizontal: 14, marginRight: 8 },
  input: { borderColor: colors.border, borderWidth: 1, borderRadius: 10, padding: 10, fontSize: 16, color: colors.text, marginVertical: 8 },
  resultatLabel: { color: colors.muted, marginTop: 6 },
  resultat: { fontSize: 28, fontWeight: '700', color: colors.up },
});
