import React, { useEffect, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useTheme, espace, typo } from '../theme';
import { ACTIONS, chargerHistorique } from '../data';
import { formaterMontant, enFcfa } from '../devises';
import { useStore } from '../store';
import { useOrdre } from '../ordre';
import { phraseAction } from '../phrases';
import CourbeCours from '../components/CourbeCours';
import Disclaimer from '../components/Disclaimer';
import Texte from '../ui/Texte';
import Carte from '../ui/Carte';
import Bouton from '../ui/Bouton';
import Chip from '../ui/Chip';
import Variation from '../ui/Variation';

const PERIODES = [
  { label: '1 mois', seances: 21 },
  { label: '3 mois', seances: 63 },
  { label: '1 an', seances: 250 },
];

function Stat({ label, valeur }) {
  const { c } = useTheme();
  return (
    <Carte style={{ flexBasis: '47%', flexGrow: 1, padding: espace.m }}>
      <Texte style={[typo.petit, { color: c.muted }]}>{label}</Texte>
      <Texte style={{ fontWeight: '700', marginTop: 2 }}>{valeur}</Texte>
    </Carte>
  );
}

export default function FicheScreen({ route, navigation }) {
  const { c } = useTheme();
  const a = ACTIONS.find((x) => x.ticker === route.params.ticker);
  const { favoris, basculerFavori } = useStore();
  const { ouvrirOrdre } = useOrdre();
  const suivi = !!favoris[a.ticker];
  const [periode, setPeriode] = useState(PERIODES[0]);
  const [points, setPoints] = useState(null);

  useEffect(() => {
    setPoints(null);
    chargerHistorique(a.ticker, periode.seances).then(setPoints);
  }, [a.ticker, periode]);

  return (
    <ScrollView style={{ backgroundColor: c.bg }} contentContainerStyle={{ padding: espace.l, gap: espace.m }}>
      <Carte>
        <Texte style={[typo.corps, { color: c.muted }]}>{a.arbre ? a.arbre + ' · ' : ''}{a.nom} · {a.bourse}, {a.pays}</Texte>
        <Texte style={typo.chiffre}>{formaterMontant(a.prix, a.devise)}</Texte>
        {a.devise === 'USD' && (
          <Texte style={[typo.petit, { color: c.muted }]}>
            environ {formaterMontant(enFcfa(a.prix, a.devise), 'FCFA')} (taux d'exemple)
          </Texte>
        )}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: espace.s, marginTop: 2 }}>
          <Variation valeur={a.var} taille={15} />
          <Texte style={[typo.petit, { color: c.muted }]}>cours de clôture</Texte>
        </View>
        <Texte style={[typo.corps, { marginTop: espace.m }]}>{phraseAction(a)}</Texte>
      </Carte>

      <Carte>
        <View style={{ flexDirection: 'row', gap: espace.s, marginBottom: espace.m }}>
          {PERIODES.map((p) => (
            <Chip key={p.label} label={p.label} actif={periode.label === p.label} onPress={() => setPeriode(p)} />
          ))}
        </View>
        <CourbeCours points={points} devise={a.devise} />
        <Texte style={[typo.petit, { color: c.muted, marginTop: espace.s }]}>
          Historique d'exemple (données fictives) tant que les données de marché sous licence ne sont pas branchées.
        </Texte>
      </Carte>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: espace.m }}>
        <Stat label="PER" valeur={a.per.toString().replace('.', ',')} />
        <Stat label="Dividende" valeur={formaterMontant(a.dividende, a.devise)} />
        <Stat label="Rendement" valeur={(a.dividende / a.prix * 100).toFixed(1).replace('.', ',') + '%'} />
        <Stat label="Bourse" valeur={a.bourse} />
      </View>

      {a.simulable ? (
        <Bouton titre="Planter dans mon jardin" onPress={() => ouvrirOrdre({ mode: 'planter', ticker: a.ticker })} />
      ) : (
        <Carte style={{ gap: espace.xs }}>
          <Texte style={{ fontWeight: '600' }}>Achat bientôt disponible</Texte>
          <Texte style={{ color: c.muted }}>
            Pour l'instant, cette valeur est présentée à titre d'information. L'achat sera proposé plus tard, avec un partenaire autorisé.
          </Texte>
        </Carte>
      )}
      <Bouton titre={suivi ? 'Ne plus suivre' : 'Suivre cette action'} variante="secondaire" onPress={() => basculerFavori(a.ticker)} />
      {a.simulable && (
        <Bouton titre="Calculer mes dividendes" variante="secondaire"
          onPress={() => navigation.navigate('Dividendes', { ticker: a.ticker })} />
      )}
      <Disclaimer />
    </ScrollView>
  );
}
