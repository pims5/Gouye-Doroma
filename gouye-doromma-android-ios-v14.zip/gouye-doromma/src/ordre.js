import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { View } from 'react-native';
import { useTheme } from './theme';
import FeuilleOrdre from './components/FeuilleOrdre';
import { useVerrou } from './verrou';
import Texte from './ui/Texte';

const Ctx = createContext(null);
export const useOrdre = () => useContext(Ctx);

// Ouvre la feuille Planter / Vendre depuis n'importe quel écran : ouvrirOrdre({ mode, ticker }).
export function OrdreProvider({ children }) {
  const { c } = useTheme();
  const { verrouille } = useVerrou();
  const [ordre, setOrdre] = useState(null);
  const [message, setMessage] = useState('');
  const minuteur = useRef(null);

  const ouvrirOrdre = useCallback((o = {}) => setOrdre({ mode: 'planter', ...o }), []);
  const fermer = useCallback(() => setOrdre(null), []);
  const annoncer = useCallback((m) => {
    setMessage(m);
    clearTimeout(minuteur.current);
    minuteur.current = setTimeout(() => setMessage(''), 2800);
  }, []);
  useEffect(() => () => clearTimeout(minuteur.current), []);
  useEffect(() => { if (verrouille) setOrdre(null); }, [verrouille]); // rien ne reste affiché derrière le verrou

  return (
    <Ctx.Provider value={{ ouvrirOrdre }}>
      {children}
      <FeuilleOrdre ordre={ordre} onFermer={fermer} onTermine={annoncer} />
      {!!message && (
        <View pointerEvents="none" accessibilityLiveRegion="polite"
          style={{ position: 'absolute', left: 16, right: 16, bottom: 96, backgroundColor: c.text, borderRadius: 14, padding: 14 }}>
          <Texte style={{ color: c.bg, fontWeight: '600' }}>{message}</Texte>
        </View>
      )}
    </Ctx.Provider>
  );
}
