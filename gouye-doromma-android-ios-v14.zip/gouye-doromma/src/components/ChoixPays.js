import React from 'react';
import { Modal, View, Pressable, ScrollView } from 'react-native';
import { useTheme, espace, rayon } from '../theme';
import { PAYS, drapeau } from '../securite';
import Texte from '../ui/Texte';

// Liste des pays de l'UEMOA (Sénégal par défaut).
export default function ChoixPays({ visible, actuel, onChoisir, onFermer }) {
  const { c } = useTheme();
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onFermer}>
      <View style={{ flex: 1, justifyContent: 'flex-end' }}>
        <Pressable accessibilityLabel="Fermer" onPress={onFermer}
          style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#00000066' }} />
        <View style={{ backgroundColor: c.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: '70%', paddingBottom: 24 }}>
          <Texte style={{ fontWeight: '600', fontSize: 16, padding: espace.l }}>Pays de votre numéro</Texte>
          <ScrollView>
            {PAYS.map((p) => (
              <Pressable key={p.id} onPress={() => onChoisir(p)} accessibilityRole="button"
                accessibilityLabel={p.nom + ', indicatif +' + p.indicatif}
                style={{ flexDirection: 'row', alignItems: 'center', gap: espace.m, paddingVertical: 14, paddingHorizontal: espace.l,
                  backgroundColor: p.id === actuel.id ? c.card : 'transparent', borderRadius: rayon.m }}>
                <Texte style={{ fontSize: 22 }}>{drapeau(p.id)}</Texte>
                <Texte style={{ flex: 1, fontSize: 16 }}>{p.nom}</Texte>
                <Texte style={{ color: c.muted }}>+{p.indicatif}</Texte>
              </Pressable>
            ))}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}
