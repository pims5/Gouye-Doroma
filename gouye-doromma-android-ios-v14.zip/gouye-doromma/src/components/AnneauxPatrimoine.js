import React, { useEffect, useRef } from 'react';
import { View, Animated, AccessibilityInfo } from 'react-native';
import Svg, { Circle, G } from 'react-native-svg';
import { useTheme, fcfa } from '../theme';
import { useT } from '../i18n';
import Texte from '../ui/Texte';

const AnimatedCircle = Animated.createAnimatedComponent(Circle);
export const TAILLES = { S: 120, M: 180, L: 240, XL: 320 };

// Wealth Ring : Capital, Croissance, Récolte, Connaissance (de l'extérieur vers l'intérieur). Chaque anneau va de 0 à 1.
export default function AnneauxPatrimoine({ progres, total, taille = 'L' }) {
  const { c } = useTheme();
  const { t } = useT();
  const px = TAILLES[taille] || TAILLES.L;
  const epais = Math.round(px * 0.055);
  const ecart = Math.round(px * 0.025);
  const m = px / 2;
  const anneaux = [
    { cle: 'capital', couleur: c.primary, v: progres.capital },
    { cle: 'growth', couleur: c.vert300, v: progres.croissance },
    { cle: 'harvest_ring', couleur: c.accent, v: progres.recolte },
    { cle: 'knowledge', couleur: c.navy, v: progres.connaissance },
  ];
  const anims = useRef(anneaux.map(() => new Animated.Value(0))).current;
  const signature = anneaux.map((a) => a.v.toFixed(3)).join(',');

  useEffect(() => {
    let actif = true;
    AccessibilityInfo.isReduceMotionEnabled().then((reduit) => {
      if (!actif) return;
      if (reduit) { anneaux.forEach((a, i) => anims[i].setValue(a.v)); return; }
      Animated.stagger(120, anneaux.map((a, i) => Animated.timing(anims[i], { toValue: a.v, duration: 800, useNativeDriver: false }))).start();
    });
    return () => { actif = false; };
  }, [signature]); // eslint-disable-line react-hooks/exhaustive-deps

  const resume = anneaux.map((a) => t(a.cle) + ' ' + Math.round(a.v * 100) + ' %').join(', ');
  return (
    <View style={{ width: px, height: px, alignSelf: 'center' }} accessible accessibilityRole="image"
      accessibilityLabel={t('garden_value') + ' ' + fcfa(total) + '. ' + resume}>
      <Svg width={px} height={px}>
        <G rotation="-90" origin={m + ', ' + m}>
          {anneaux.map((a, i) => {
            const r = m - epais / 2 - i * (epais + ecart);
            const C = 2 * Math.PI * r;
            return (
              <React.Fragment key={a.cle}>
                <Circle cx={m} cy={m} r={r} stroke={c.border} strokeWidth={epais} fill="none" />
                {a.v > 0 && (
                  <AnimatedCircle cx={m} cy={m} r={r} fill="none" stroke={a.couleur} strokeWidth={epais} strokeLinecap="round"
                    strokeDasharray={[C, C]} strokeDashoffset={anims[i].interpolate({ inputRange: [0, 1], outputRange: [C, 0] })} />
                )}
              </React.Fragment>
            );
          })}
        </G>
      </Svg>
      {px >= 180 && (
        <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' }}>
          <Texte style={{ fontSize: Math.round(px * 0.072), fontWeight: '700', fontVariant: ['tabular-nums'] }}>
            {Math.round(total).toLocaleString('fr-FR')}
          </Texte>
          <Texte style={{ color: c.muted, fontSize: 11 }}>FCFA</Texte>
          {px >= 240 && <Texte style={{ color: c.muted, fontSize: 10 }}>{t('garden_value')}</Texte>}
        </View>
      )}
    </View>
  );
}
