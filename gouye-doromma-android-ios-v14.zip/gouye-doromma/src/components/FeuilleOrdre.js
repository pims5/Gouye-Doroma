import React, { useEffect, useMemo, useState } from 'react';
import { Modal, View, ScrollView, Pressable, TextInput, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useTheme, fcfa, espace, rayon, police } from '../theme';
import { ACTIONS as TOUTES } from '../data';
const ACTIONS = TOUTES.filter((a) => a.simulable); // les valeurs internationales sont en information seulement
import { useStore } from '../store';
import { resumeJardin } from '../jardin';
import Texte from '../ui/Texte';
import Carte from '../ui/Carte';
import Bouton from '../ui/Bouton';
import Chip from '../ui/Chip';

const IOS = Platform.OS === 'ios';

// Feuille « Planter / Vendre ». iPhone : feuille native (pageSheet). Android : feuille du bas avec fond assombri.
export default function FeuilleOrdre({ ordre, onFermer, onTermine }) {
  const { c } = useTheme();
  const { cash, lots, positions, planter, vendre } = useStore();
  const [mode, setMode] = useState('planter');
  const [ticker, setTicker] = useState(ACTIONS[0].ticker);
  const [saisie, setSaisie] = useState('10');

  useEffect(() => {
    if (!ordre) return;
    setMode(ordre.mode);
    const premier = ordre.mode === 'vendre' ? ACTIONS.find((a) => positions[a.ticker] > 0) : ACTIONS[0];
    setTicker(ordre.ticker || (premier || ACTIONS[0]).ticker);
    setSaisie('10');
  }, [ordre]); // eslint-disable-line react-hooks/exhaustive-deps

  const a = ACTIONS.find((x) => x.ticker === ticker) || ACTIONS[0];
  const detenu = positions[a.ticker] || 0;
  const max = mode === 'planter' ? Math.floor(cash / a.prix) : detenu;
  const qte = parseInt(saisie, 10) || 0;
  const montant = qte * a.prix;
  const total = useMemo(() => resumeJardin(lots, cash).total, [lots, cash]);
  const choix = mode === 'planter' ? ACTIONS : ACTIONS.filter((x) => positions[x.ticker] > 0);
  const erreur = qte > max
    ? (mode === 'planter' ? 'Solde fictif insuffisant (maximum ' + max + ' actions).' : "Vous n'en détenez que " + detenu + '.')
    : '';
  const valide = qte >= 1 && qte <= max;

  const regler = (n) => setSaisie(String(Math.max(1, n)));
  const confirmer = () => {
    const r = mode === 'planter' ? planter(a, qte) : vendre(a, qte);
    if (!r.ok) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    onTermine(r.message);
    onFermer();
  };

  const rond = (nom, label, onPress) => (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={label}
      style={{ width: 52, height: 52, borderRadius: 26, borderWidth: 1, borderColor: c.border, backgroundColor: c.card,
        alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={nom} size={24} color={c.primary} />
    </Pressable>
  );

  const corps = (
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: espace.l, paddingBottom: 36, gap: espace.m }}>
      <View style={{ flexDirection: 'row', gap: espace.s }}>
        <Chip label="Planter" actif={mode === 'planter'} onPress={() => { setMode('planter'); setTicker(ACTIONS[0].ticker); }} />
        <Chip label="Vendre" actif={mode === 'vendre'} onPress={() => {
          setMode('vendre');
          const p = ACTIONS.find((x) => positions[x.ticker] > 0);
          if (p) setTicker(p.ticker);
        }} />
      </View>

      {choix.length === 0 ? (
        <Texte style={{ color: c.muted }}>Vous ne détenez aucune action à vendre pour l'instant.</Texte>
      ) : (
        <>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: espace.s }}>
            {choix.map((x) => <Chip key={x.ticker} label={x.ticker} actif={x.ticker === a.ticker} onPress={() => setTicker(x.ticker)} />)}
          </ScrollView>
          <Texte style={{ color: c.muted }}>
            {a.nom} · {fcfa(a.prix)}{mode === 'vendre' ? ' · vous en détenez ' + detenu : ''}
          </Texte>

          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: espace.l }}>
            {rond('remove', 'Diminuer la quantité', () => regler(qte - 1))}
            <TextInput
              value={saisie}
              onChangeText={(t) => setSaisie(t.replace(/[^0-9]/g, ''))}
              keyboardType="number-pad"
              accessibilityLabel="Quantité d'actions"
              style={{ minWidth: 96, textAlign: 'center', fontSize: 34, fontFamily: police.gras, color: c.text, fontVariant: ['tabular-nums'] }}
            />
            {rond('add', 'Augmenter la quantité', () => regler(qte + 1))}
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'center', gap: espace.s }}>
            <Chip label="+10" onPress={() => regler(qte + 10)} />
            <Chip label="+50" onPress={() => regler(qte + 50)} />
            <Chip label="Max" onPress={() => regler(max)} />
          </View>

          <Carte style={{ gap: espace.s }}>
            <Ligne c={c} label={mode === 'planter' ? 'Montant' : 'Vous recevrez'} valeur={fcfa(montant)} fort />
            {mode === 'planter' && total > 0 && <Ligne c={c} label="Part du jardin" valeur={(montant / total * 100).toFixed(0) + ' %'} />}
            {mode === 'planter' && <Ligne c={c} label="Récolte attendue par an" valeur={fcfa(qte * a.dividende)} />}
            <Ligne c={c} label="Liquidités après" valeur={fcfa(mode === 'planter' ? cash - montant : cash + montant)} />
          </Carte>

          {!!erreur && <Texte style={{ color: c.down }} accessibilityLiveRegion="polite">{erreur}</Texte>}
          <Bouton titre={(mode === 'planter' ? 'Planter ' : 'Vendre ') + qte + ' actions'} onPress={confirmer} desactive={!valide} />
          <Texte style={{ color: c.muted, fontSize: 12, textAlign: 'center' }}>Argent fictif. Rien n'est acheté pour de vrai.</Texte>
        </>
      )}
      {!IOS && <Pressable onPress={onFermer} accessibilityRole="button" style={{ alignItems: 'center', padding: espace.m }}>
        <Texte style={{ color: c.primary, fontWeight: '600' }}>Annuler</Texte>
      </Pressable>}
    </ScrollView>
  );

  return (
    <Modal visible={!!ordre} animationType="slide" transparent={!IOS}
      presentationStyle={IOS ? 'pageSheet' : undefined} onRequestClose={onFermer}>
      {IOS ? (
        <View style={{ flex: 1, backgroundColor: c.bg }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: espace.l }}>
            <Pressable onPress={onFermer} accessibilityRole="button" accessibilityLabel="Annuler">
              <Texte style={{ color: c.primary }}>Annuler</Texte>
            </Pressable>
            <Texte style={{ fontWeight: '600' }}>{mode === 'planter' ? 'Planter' : 'Vendre'}</Texte>
            <View style={{ width: 52 }} />
          </View>
          {corps}
        </View>
      ) : (
        <View style={{ flex: 1, justifyContent: 'flex-end' }}>
          <Pressable accessibilityLabel="Fermer" onPress={onFermer}
            style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#00000066' }} />
          <View style={{ backgroundColor: c.bg, borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: '92%' }}>
            <View style={{ width: 36, height: 4, borderRadius: 2, backgroundColor: c.border, alignSelf: 'center', marginTop: 10 }} />
            {corps}
          </View>
        </View>
      )}
    </Modal>
  );
}

function Ligne({ c, label, valeur, fort }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
      <Texte style={{ color: c.muted }}>{label}</Texte>
      <Texte style={{ fontWeight: fort ? '700' : '600', fontVariant: ['tabular-nums'] }}>{valeur}</Texte>
    </View>
  );
}
