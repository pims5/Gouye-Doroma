import React, { useEffect, useState } from 'react';
import { View, Switch } from 'react-native';
import { useTheme, espace } from '../theme';
import { useVerrou } from '../verrou';
import { DELAIS } from '../securite';
import Texte from '../ui/Texte';
import Carte from '../ui/Carte';
import Chip from '../ui/Chip';

export default function CarteSecurite() {
  const { c } = useTheme();
  const { actif, delai, activerBiometrie, desactiver, regler, biometrieDisponible } = useVerrou();
  const [dispo, setDispo] = useState(true);
  const [msg, setMsg] = useState('');
  useEffect(() => { biometrieDisponible().then(setDispo); }, [biometrieDisponible]);

  const basculer = async (v) => {
    setMsg('');
    const ok = v ? await activerBiometrie() : await desactiver();
    if (!ok) setMsg(v ? "Activation impossible : configurez Face ID ou l'empreinte dans les réglages du téléphone." : 'Confirmation refusée.');
  };

  return (
    <Carte style={{ marginBottom: espace.m, gap: espace.s }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flex: 1, paddingRight: espace.m }}>
          <Texte style={{ fontWeight: '600' }}>Protection Face ID / empreinte</Texte>
          <Texte style={{ color: c.muted, fontSize: 12 }}>Demandée quand vous revenez dans l'application.</Texte>
        </View>
        <Switch value={actif} onValueChange={basculer} disabled={!dispo && !actif}
          trackColor={{ true: c.primary }} accessibilityLabel="Protection Face ID ou empreinte" />
      </View>
      {actif && (
        <>
          <Texte style={{ color: c.muted, fontSize: 12 }}>Reverrouiller après</Texte>
          <View style={{ flexDirection: 'row', gap: espace.s, flexWrap: 'wrap' }}>
            {DELAIS.map((d) => <Chip key={d.id} label={d.label} actif={delai === d.id} onPress={() => regler(d.id)} />)}
          </View>
        </>
      )}
      {!dispo && !actif && <Texte style={{ color: c.muted, fontSize: 12 }}>Aucune biométrie configurée sur ce téléphone.</Texte>}
      {!!msg && <Texte style={{ color: c.down }} accessibilityLiveRegion="polite">{msg}</Texte>}
    </Carte>
  );
}
