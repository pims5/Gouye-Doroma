import React, { useEffect, useRef } from 'react';
import { Animated, AccessibilityInfo, Pressable } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { useTheme } from '../theme';

const AC = Animated.createAnimatedComponent(Circle);
const R = 14, C = 2 * Math.PI * R, T = 38;

// Le code se saisit dans des anneaux qui se remplissent, un par chiffre.
export default function AnneauxCode({ valeur, longueur = 6, onPress, erreur }) {
  const { c } = useTheme();
  const anims = useRef(Array.from({ length: longueur }, () => new Animated.Value(0))).current;

  useEffect(() => {
    let actif = true;
    AccessibilityInfo.isReduceMotionEnabled().then((reduit) => {
      if (!actif) return;
      anims.forEach((a, i) => {
        const cible = i < valeur.length ? 1 : 0;
        if (reduit) a.setValue(cible);
        else Animated.timing(a, { toValue: cible, duration: 300, useNativeDriver: false }).start();
      });
    });
    return () => { actif = false; };
  }, [valeur, anims]);

  return (
    <Pressable onPress={onPress} accessibilityLabel={'Code à ' + longueur + ' chiffres, ' + valeur.length + ' saisis'}
      style={{ flexDirection: 'row', gap: 8, justifyContent: 'center' }}>
      {anims.map((a, i) => (
        <Svg key={i} width={T} height={T} viewBox="0 0 38 38">
          <Circle cx="19" cy="19" r={R} stroke={erreur ? c.down : c.border} strokeWidth="3" fill="none" />
          <AC cx="19" cy="19" r={R} stroke={erreur ? c.down : c.primary} strokeWidth="3" fill="none" strokeLinecap="round"
            rotation="-90" origin="19, 19" strokeDasharray={[C, C]}
            strokeDashoffset={a.interpolate({ inputRange: [0, 1], outputRange: [C, 0] })} />
          <AC cx="19" cy="19" r="3" fill={c.or} fillOpacity={a} />
        </Svg>
      ))}
    </Pressable>
  );
}
