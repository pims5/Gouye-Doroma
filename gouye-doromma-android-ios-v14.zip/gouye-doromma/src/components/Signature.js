import React from 'react';
import { View } from 'react-native';
import { useTheme } from '../theme';
import Texte from '../ui/Texte';

// Signature « BY COUSOUM INC » : affichée uniquement sur l'écran d'accueil (Jardin), en bas du contenu.
export default function Signature() {
  const { c } = useTheme();
  return (
    <View accessible accessibilityLabel="by COUSOUM INC" style={{ alignItems: 'center', gap: 7, paddingVertical: 24 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <View style={{ width: 30, height: 1, backgroundColor: c.or }} />
        <View style={{ width: 5, height: 5, backgroundColor: c.or, transform: [{ rotate: '45deg' }] }} />
        <View style={{ width: 30, height: 1, backgroundColor: c.or }} />
      </View>
      <Texte style={{ fontSize: 9, letterSpacing: 3.4, color: c.or, fontWeight: '600' }}>BY COUSOUM INC</Texte>
    </View>
  );
}
