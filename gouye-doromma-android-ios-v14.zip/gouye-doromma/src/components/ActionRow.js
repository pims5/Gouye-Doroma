import React from 'react';
import { View, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, espace, rayon, typo } from '../theme';
import { formaterMontant } from '../devises';
import { useStore } from '../store';
import Texte from '../ui/Texte';
import Variation from '../ui/Variation';

export default function ActionRow({ action, onPress }) {
  const { c } = useTheme();
  const { favoris } = useStore();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={action.nom + ', ' + formaterMontant(action.prix, action.devise)}
      style={({ pressed }) => ({
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: espace.m,
        backgroundColor: c.card, borderColor: c.border, borderWidth: 1, borderRadius: rayon.l,
        padding: espace.l, opacity: pressed ? 0.85 : 1,
      })}
    >
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Texte style={typo.sousTitre}>{action.arbre || action.ticker}</Texte>
          {!!favoris[action.ticker] && <Ionicons name="star" size={14} color={c.accent} />}
        </View>
        <Texte style={[typo.petit, { color: c.muted }]} numberOfLines={1}>{action.arbre ? action.ticker + ' · ' + action.nom : action.nom + ' · ' + action.pays}</Texte>
      </View>
      <View style={{ alignItems: 'flex-end', gap: 2 }}>
        <Texte style={{ fontWeight: '600', fontVariant: ['tabular-nums'] }}>{formaterMontant(action.prix, action.devise)}</Texte>
        <Variation valeur={action.var} />
      </View>
    </Pressable>
  );
}
