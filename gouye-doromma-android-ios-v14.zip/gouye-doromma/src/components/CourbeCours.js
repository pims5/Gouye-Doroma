import React, { useState } from 'react';
import { View } from 'react-native';
import Text from '../ui/Texte';
import Svg, { Path } from 'react-native-svg';
import { useTheme, pct } from '../theme';
import { formaterMontant } from '../devises';

const H = 140;

export default function CourbeCours({ points, devise = 'FCFA' }) {
  const { c: colors } = useTheme();
  const [w, setW] = useState(0);
  if (!points || points.length < 2) {
    return <Text style={{ color: colors.muted }}>Chargement de l'historique…</Text>;
  }

  const prix = points.map((p) => p.prix);
  const min = Math.min(...prix);
  const max = Math.max(...prix);
  const ecart = max - min || 1;
  const variation = (prix[prix.length - 1] / prix[0] - 1) * 100;
  const couleur = variation >= 0 ? colors.up : colors.down;

  const x = (i) => (i / (prix.length - 1)) * w;
  const y = (v) => 8 + (1 - (v - min) / ecart) * (H - 16);
  const ligne = prix.map((v, i) => (i === 0 ? 'M' : 'L') + x(i).toFixed(1) + ' ' + y(v).toFixed(1)).join(' ');
  const aire = ligne + ' L' + w + ' ' + H + ' L0 ' + H + ' Z';

  return (
    <View>
      <Text style={{ color: couleur, fontWeight: '700' }}>{pct(variation)} sur la période</Text>
      <View onLayout={(e) => setW(e.nativeEvent.layout.width)} style={{ height: H, marginTop: 6 }}>
        {w > 0 && (
          <Svg width={w} height={H}>
            <Path d={aire} fill={couleur} opacity={0.1} />
            <Path d={ligne} stroke={couleur} strokeWidth={2} fill="none" />
          </Svg>
        )}
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 }}>
        <Text style={{ color: colors.muted, fontSize: 12 }}>Plus bas : {formaterMontant(min, devise)}</Text>
        <Text style={{ color: colors.muted, fontSize: 12 }}>Plus haut : {formaterMontant(max, devise)}</Text>
      </View>
    </View>
  );
}
