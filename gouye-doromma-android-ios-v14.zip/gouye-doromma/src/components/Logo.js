import React from 'react';
import Svg, { Path, Circle, Polygon } from 'react-native-svg';
import { useTheme } from '../theme';

const VERT = '#00853F', JAUNE = '#F2C200', ROUGE = '#E31B23';
const ETOILE = Array.from({ length: 10 }, (_, i) => {
  const a = ((-90 + i * 36) * Math.PI) / 180;
  const r = i % 2 === 0 ? 14 : 5.6;
  return (120 + r * Math.cos(a)).toFixed(1) + ',' + (92 + r * Math.sin(a)).toFixed(1);
}).join(' ');

// Baobab aux trois anneaux (couleurs du drapeau), étoile verte, anneau extérieur ouvert vers le monde.
export default function Logo({ taille = 96 }) {
  const { c } = useTheme();
  return (
    <Svg width={(taille * 158) / 216} height={taille} viewBox="46 18 158 216" accessibilityLabel="Logo Gouye Doromma">
      <Path d="M92 146 C96 176 70 198 58 232 L182 232 C170 198 144 176 148 146 Z" fill={c.text} />
      <Circle cx="120" cy="92" r="66" fill="none" stroke={VERT} strokeWidth="11" strokeLinecap="round" strokeDasharray="354 61" />
      <Circle cx="120" cy="92" r="48" fill="none" stroke={JAUNE} strokeWidth="11" />
      <Circle cx="120" cy="92" r="30" fill="none" stroke={ROUGE} strokeWidth="11" />
      <Polygon points={ETOILE} fill={VERT} />
      <Circle cx="192" cy="60" r="8.5" fill={VERT} />
    </Svg>
  );
}
