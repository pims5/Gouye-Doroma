import React from 'react';
import Text from '../ui/Texte';
import { useTheme } from '../theme';

export default function Disclaimer() {
  const { c: colors } = useTheme();
  return (
    <Text style={{ color: colors.muted, fontSize: 12, textAlign: 'center', padding: 16 }}>
      Information et éducation, pas un conseil en investissement. Aucun ordre n'est passé depuis cette application.
    </Text>
  );
}
