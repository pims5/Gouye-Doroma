// Formats FCFA et dollars. Le taux est un EXEMPLE : à remplacer par un taux de change réel (source à choisir).
export const TAUX_USD_FCFA = 600;
const groupe = (s) => s.replace(/\B(?=(\d{3})+(?!\d))/g, '\u202f');

export function formaterMontant(n, devise = 'FCFA') {
  const neg = n < 0 ? '-' : '';
  if (devise === 'USD') {
    const [e, d] = Math.abs(n).toFixed(2).split('.');
    return neg + groupe(e) + ',' + d + '\u00a0$';
  }
  return neg + groupe(String(Math.round(Math.abs(n)))) + '\u00a0FCFA';
}
export const enFcfa = (n, devise = 'FCFA') => (devise === 'USD' ? n * TAUX_USD_FCFA : n);
