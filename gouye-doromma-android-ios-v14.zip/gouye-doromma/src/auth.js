import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { supabase } from './supabase';

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

const traduire = (e, contexte) => {
  const m = (e && e.message) || '';
  if (!e) return null;
  if (/rate limit|security purposes|too many/i.test(m)) return 'Patientez un instant avant de redemander un code.';
  if (/provider|sms|twilio|whatsapp/i.test(m) && contexte === 'envoi') return "L'envoi du code est indisponible pour le moment. Réessayez plus tard.";
  if (contexte === 'envoi' && /invalid|phone/i.test(m)) return 'Numéro refusé. Vérifiez-le.';
  if (/expired|invalid/i.test(m)) return 'Code incorrect ou expiré. Vérifiez-le ou demandez-en un nouveau.';
  return 'Une erreur est survenue. Vérifiez votre connexion et réessayez.';
};

// Connexion sans mot de passe : un code à 6 chiffres reçu par SMS ou WhatsApp crée le compte ou ouvre la session.
export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [chargement, setChargement] = useState(true);
  const fraiche = useRef(false); // vrai juste après une saisie de code : pas de verrouillage biométrique immédiat

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setChargement(false);
    });
    const { data } = supabase.auth.onAuthStateChange((_evt, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  const envoyerCode = async (telephone, canal = 'sms') => {
    const { error } = await supabase.auth.signInWithOtp({ phone: telephone, options: { shouldCreateUser: true, channel: canal } });
    return { erreur: traduire(error, 'envoi') };
  };
  const verifierCode = async (telephone, code) => {
    fraiche.current = true;
    const { error } = await supabase.auth.verifyOtp({ phone: telephone, token: code, type: 'sms' }); // même type pour SMS et WhatsApp
    if (error) fraiche.current = false;
    return { erreur: traduire(error) };
  };
  const definirPrenom = async (prenom) => {
    const { error } = await supabase.auth.updateUser({ data: { prenom } });
    return { erreur: traduire(error) };
  };
  const deconnecter = async () => {
    fraiche.current = false;
    await supabase.auth.signOut();
  };
  const supprimerCompte = async () => {
    const { error } = await supabase.rpc('supprimer_mon_compte');
    if (!error) await deconnecter();
    return { erreur: traduire(error) };
  };

  const meta = session && session.user ? session.user.user_metadata : null;
  const prenom = (meta && meta.prenom) || '';

  return (
    <Ctx.Provider value={{ session, chargement, prenom, fraiche, envoyerCode, verifierCode, definirPrenom, deconnecter, supprimerCompte }}>
      {children}
    </Ctx.Provider>
  );
}
