import { ACTIONS } from './data';

// Un « lot » = une plantation : { id, ticker, qte, prix, date }. Le portefeuille est la liste des lots.
const action = (t) => ACTIONS.find((a) => a.ticker === t);
const prixDe = (t) => (action(t) ? action(t).prix : 0);
const dividendeDe = (t) => (action(t) ? action(t).dividende : 0);

export const idLot = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

export function positionsParTitre(lots) {
  const p = {};
  for (const l of lots) p[l.ticker] = (p[l.ticker] || 0) + l.qte;
  return p;
}

// Ancien format { ticker: quantité } -> lots datés d'aujourd'hui, au cours actuel.
export function migrerPositions(positions, date = new Date()) {
  return Object.entries(positions || {})
    .filter(([, q]) => Number(q) > 0)
    .map(([ticker, q]) => ({ id: idLot(), ticker, qte: Number(q), prix: prixDe(ticker), date: date.toISOString() }));
}

// Vente : on retire d'abord les lots les plus anciens (premier entré, premier sorti).
export function retirerLots(lots, ticker, qte) {
  let reste = qte;
  const out = [];
  for (const l of lots) {
    if (l.ticker !== ticker || reste === 0) { out.push(l); continue; }
    const pris = Math.min(l.qte, reste);
    reste -= pris;
    if (l.qte > pris) out.push({ ...l, qte: l.qte - pris });
  }
  return out;
}

// Une ligne par année de plantation. progression : 1 pour une année passée, part écoulée pour l'année en cours.
export function resumeJardin(lots, cash, maintenant = new Date()) {
  const parAnnee = {};
  for (const l of lots) {
    const an = new Date(l.date).getFullYear();
    const o = parAnnee[an] || (parAnnee[an] = { annee: an, cout: 0, valeur: 0 });
    o.cout += l.qte * l.prix;
    o.valeur += l.qte * prixDe(l.ticker);
  }
  const anCourant = maintenant.getFullYear();
  const debut = new Date(anCourant, 0, 1);
  const fin = new Date(anCourant + 1, 0, 1);
  const annees = Object.values(parAnnee).sort((a, b) => a.annee - b.annee).map((o) => ({
    ...o,
    perf: o.cout ? (o.valeur / o.cout - 1) * 100 : 0,
    progression: o.annee < anCourant ? 1 : (maintenant - debut) / (fin - debut),
  }));
  const valeurTitres = annees.reduce((s, o) => s + o.valeur, 0);
  const cout = annees.reduce((s, o) => s + o.cout, 0);
  return {
    annees, valeurTitres, cout, total: valeurTitres + cash,
    gainPct: cout ? (valeurTitres / cout - 1) * 100 : 0,
    dividendesAn: lots.reduce((s, l) => s + l.qte * dividendeDe(l.ticker), 0),
  };
}

// Quatre anneaux du patrimoine. Les plafonds sont des repères d'affichage (à valider avec la marque et la conformité).
export const CAP_CROISSANCE = 20; // % de gain pour un anneau plein
export const CAP_RECOLTE = 10; // % de rendement estimé pour un anneau plein
const borne = (x) => Math.max(0, Math.min(1, x));
export function progresPatrimoine(resume, connaissance) {
  const rendement = resume.valeurTitres > 0 ? (resume.dividendesAn / resume.valeurTitres) * 100 : 0;
  return {
    capital: borne(resume.total > 0 ? resume.valeurTitres / resume.total : 0), // part du patrimoine plantée
    croissance: borne(resume.gainPct / CAP_CROISSANCE),
    recolte: borne(rendement / CAP_RECOLTE),
    connaissance: borne(connaissance), // leçons terminées / total
    rendement,
  };
}
