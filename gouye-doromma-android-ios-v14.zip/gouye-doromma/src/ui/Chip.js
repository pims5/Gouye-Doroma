import React from 'react';
import { Pressable } from 'react-native';
import { useTheme, rayon } from '../theme';
import Texte from './Texte';

export default function Chip({ label, actif, onPress }) {
  const { c } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: !!actif }}
      style={{ minHeight: 40, justifyContent: 'center', paddingHorizontal: 16, borderRadius: rayon.pill,
        borderWidth: 1, borderColor: actif ? c.primary : c.border, backgroundColor: actif ? c.primary : 'transparent' }}
    >
      <Texte style={{ color: actif ? c.surPrimaire : c.text, fontWeight: '600', fontSize: 14 }}>{label}</Texte>
    </Pressable>
  );
}
