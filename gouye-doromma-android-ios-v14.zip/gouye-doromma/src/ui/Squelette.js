import React, { useEffect, useRef } from 'react';
import { Animated } from 'react-native';
import { useTheme, rayon } from '../theme';

// Bloc gris qui pulse pendant le chargement.
export default function Squelette({ hauteur = 16, largeur = '100%', style }) {
  const { c } = useTheme();
  const o = useRef(new Animated.Value(0.4)).current;
  useEffect(() => {
    const anim = Animated.loop(Animated.sequence([
      Animated.timing(o, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(o, { toValue: 0.4, duration: 700, useNativeDriver: true }),
    ]));
    anim.start();
    return () => anim.stop();
  }, [o]);
  return <Animated.View accessibilityLabel="Chargement"
    style={[{ height: hauteur, width: largeur, borderRadius: rayon.s, backgroundColor: c.border, opacity: o }, style]} />;
}
