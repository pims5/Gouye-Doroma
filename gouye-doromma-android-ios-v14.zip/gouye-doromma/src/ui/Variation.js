import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../theme';
import Texte from './Texte';

// Le sens est indiqué par une flèche et un libellé d'accessibilité, pas seulement par la couleur.
export default function Variation({ valeur, taille = 13, couleur }) {
  const { c } = useTheme();
  const hausse = valeur >= 0;
  const coul = couleur || (hausse ? c.up : c.down);
  const abs = Math.abs(valeur).toFixed(2).replace('.', ',');
  return (
    <View accessible accessibilityLabel={(hausse ? 'Hausse de ' : 'Baisse de ') + abs + ' pour cent'}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
      <Ionicons name={hausse ? 'caret-up' : 'caret-down'} size={taille} color={coul} />
      <Texte style={{ color: coul, fontSize: taille, fontWeight: '600', fontVariant: ['tabular-nums'] }}>{abs}%</Texte>
    </View>
  );
}
