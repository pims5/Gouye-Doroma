import React from 'react';
import { View } from 'react-native';
import { useTheme, rayon, espace } from '../theme';

export default function Carte({ style, children, ...props }) {
  const { c } = useTheme();
  return (
    <View {...props} style={[{ backgroundColor: c.card, borderColor: c.border, borderWidth: 1,
      borderRadius: rayon.l, padding: espace.l }, style]}>
      {children}
    </View>
  );
}
