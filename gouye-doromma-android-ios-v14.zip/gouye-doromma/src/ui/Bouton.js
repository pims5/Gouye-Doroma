import React from 'react';
import { Pressable, ActivityIndicator } from 'react-native';
import { useTheme, rayon } from '../theme';
import Texte from './Texte';

// variante : 'primaire' | 'secondaire' | 'danger'. Hauteur minimale 48 pour le tactile.
export default function Bouton({ titre, onPress, variante = 'primaire', chargement = false, desactive = false, style }) {
  const { c } = useTheme();
  const v = {
    primaire: { bg: c.primary, tx: c.surPrimaire, bd: c.primary },
    secondaire: { bg: 'transparent', tx: c.primary, bd: c.primary },
    recolte: { bg: c.accent, tx: '#1F1300', bd: c.accent },
    danger: { bg: 'transparent', tx: c.down, bd: c.down },
  }[variante];
  const inactif = desactive || chargement;
  return (
    <Pressable
      onPress={onPress}
      disabled={inactif}
      accessibilityRole="button"
      accessibilityLabel={titre}
      accessibilityState={{ disabled: inactif, busy: chargement }}
      style={({ pressed }) => [{
        minHeight: 48, borderRadius: rayon.m, borderWidth: 1, borderColor: v.bd, backgroundColor: v.bg,
        alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16,
        opacity: desactive ? 0.5 : pressed ? 0.8 : 1,
      }, style]}
    >
      {chargement
        ? <ActivityIndicator color={v.tx} />
        : <Texte style={{ color: v.tx, fontWeight: '600', fontSize: 16 }}>{titre}</Texte>}
    </Pressable>
  );
}
