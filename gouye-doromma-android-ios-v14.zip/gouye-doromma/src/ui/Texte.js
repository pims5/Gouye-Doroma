import React from 'react';
import { Text as RNText, StyleSheet } from 'react-native';
import { police, useTheme } from '../theme';

// Remplace <Text> : Manrope pour les titres (600, 700), Inter pour le texte (400, 500), couleur du thème.
export default function Texte({ style, ...props }) {
  const { c } = useTheme();
  const w = String(StyleSheet.flatten(style)?.fontWeight || '400');
  const famille = ['700', '800', '900', 'bold'].includes(w) ? police.gras
    : w === '600' ? police.demi : w === '500' ? police.moyen : police.normal;
  return <RNText {...props} style={[{ fontFamily: famille, color: c.text }, style, { fontWeight: undefined }]} />;
}
