import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, espace } from '../theme';
import Texte from './Texte';
import Bouton from './Bouton';

// Écran vide ou en erreur : dit ce qui se passe et propose une action.
export default function EtatVide({ icone = 'search', titre, texte, actionTitre, onAction }) {
  const { c } = useTheme();
  return (
    <View style={{ alignItems: 'center', padding: espace.xl, gap: espace.s }}>
      <Ionicons name={icone} size={40} color={c.muted} />
      <Texte style={{ fontSize: 17, fontWeight: '600', textAlign: 'center' }}>{titre}</Texte>
      {!!texte && <Texte style={{ color: c.muted, textAlign: 'center' }}>{texte}</Texte>}
      {!!actionTitre && <Bouton titre={actionTitre} onPress={onAction} variante="secondaire" style={{ marginTop: espace.s }} />}
    </View>
  );
}
