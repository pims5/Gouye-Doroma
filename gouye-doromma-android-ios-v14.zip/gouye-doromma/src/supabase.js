import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

// Vrai si le fichier .env est rempli.
export const configure = !!url && !!key && !url.includes('VOTRE-PROJET');

export const supabase = createClient(
  configure ? url : 'https://placeholder.supabase.co',
  configure ? key : 'placeholder',
  { auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false } }
);
