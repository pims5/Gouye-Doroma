import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { supabase } from './supabase';
import { useAuth } from './auth';
import { idLot, migrerPositions, positionsParTitre, retirerLots } from './jardin';

const Ctx = createContext(null);
export const useStore = () => useContext(Ctx);

const CASH_INITIAL = 1000000;

export function StoreProvider({ children }) {
  const { session } = useAuth();
  const uid = session ? session.user.id : null;
  const [cash, setCash] = useState(CASH_INITIAL);
  const [lots, setLots] = useState([]);
  const [favoris, setFavoris] = useState({});
  const [pret, setPret] = useState(false); // vrai une fois les données du compte chargées

  // Chargement à la connexion. Colonne `positions` : { v: 2, lots } (l'ancien format { ticker: qte } est converti).
  useEffect(() => {
    setPret(false);
    setCash(CASH_INITIAL); setLots([]); setFavoris({});
    if (!uid) return;
    let actif = true;
    supabase.from('donnees_utilisateur').select('cash, positions, favoris').eq('user_id', uid).maybeSingle()
      .then(({ data, error }) => {
        if (!actif || error) return; // hors connexion : on n'écrase jamais les données du compte
        if (data) {
          setCash(Number(data.cash));
          const p = data.positions || {};
          setLots(p.v === 2 ? p.lots || [] : migrerPositions(p));
          setFavoris(data.favoris || {});
        }
        setPret(true);
      });
    return () => { actif = false; };
  }, [uid]);

  // Sauvegarde après chaque changement (avec un court délai)
  useEffect(() => {
    if (!uid || !pret) return;
    const t = setTimeout(() => {
      supabase.from('donnees_utilisateur').upsert({
        user_id: uid, cash, positions: { v: 2, lots }, favoris, updated_at: new Date().toISOString(),
      });
    }, 800);
    return () => clearTimeout(t);
  }, [cash, lots, favoris, uid, pret]);

  const positions = useMemo(() => positionsParTitre(lots), [lots]);

  const planter = (action, qte) => {
    const montant = action.prix * qte;
    if (qte < 1) return { ok: false, message: 'Choisissez au moins 1 action.' };
    if (montant > cash) return { ok: false, message: 'Solde fictif insuffisant.' };
    setCash(cash - montant);
    setLots([...lots, { id: idLot(), ticker: action.ticker, qte, prix: action.prix, date: new Date().toISOString() }]);
    return { ok: true, message: qte + ' ' + action.ticker + ' plantées dans votre jardin.' };
  };

  const vendre = (action, qte) => {
    if (qte < 1) return { ok: false, message: 'Choisissez au moins 1 action.' };
    if ((positions[action.ticker] || 0) < qte) return { ok: false, message: "Vous n'en détenez pas assez." };
    setCash(cash + action.prix * qte);
    setLots(retirerLots(lots, action.ticker, qte));
    return { ok: true, message: qte + ' ' + action.ticker + ' vendues.' };
  };

  const basculerFavori = (t) => setFavoris({ ...favoris, [t]: !favoris[t] });

  return (
    <Ctx.Provider value={{ cash, lots, positions, favoris, planter, vendre, basculerFavori }}>
      {children}
    </Ctx.Provider>
  );
}
