import React, { createContext, useContext, useEffect, useState } from 'react';
import { useColorScheme } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Jetons de design. Les clés bg/card/text/muted/primary/up/down/border sont utilisées partout.
const clair = {
  bg: '#F7F6F2', card: '#FFFFFF', text: '#152238', muted: '#5B6678', border: '#E3E1D8',
  primary: '#145A4B', surPrimaire: '#FFFFFF', accent: '#F6A53A', or: '#8C6A2F', up: '#12805C', down: '#C4372C',
  vert300: '#A8D5B2', navy: '#152238',
};
const sombre = {
  bg: '#0B1210', card: '#15211C', text: '#E8EFEA', muted: '#9DB0A6', border: '#25362E',
  primary: '#67D39A', surPrimaire: '#0B1210', accent: '#F6A53A', or: '#B88C4A', up: '#67D39A', down: '#FF7A6B',
  vert300: '#A8D5B2', navy: '#C7D2E4',
};

export const espace = { xs: 4, s: 8, m: 12, l: 16, xl: 24, xxl: 32 };
export const rayon = { s: 8, m: 12, l: 16, xl: 22, pill: 999 };
export const police = { normal: 'Inter_400Regular', moyen: 'Inter_500Medium', demi: 'Manrope_600SemiBold', gras: 'Manrope_700Bold', marque: 'Lora_500Medium' };
// La graisse est convertie en police par le composant Texte (src/ui/Texte.js).
export const typo = {
  h1: { fontSize: 40, lineHeight: 48, fontWeight: '700' },
  h2: { fontSize: 32, lineHeight: 40, fontWeight: '700' },
  titre: { fontSize: 24, lineHeight: 30, fontWeight: '600' },
  sousTitre: { fontSize: 17, lineHeight: 22, fontWeight: '600' },
  corps: { fontSize: 16, lineHeight: 24 },
  petit: { fontSize: 12, lineHeight: 17, fontWeight: '500' },
  chiffre: { fontSize: 28, lineHeight: 34, fontWeight: '700', fontVariant: ['tabular-nums'] },
};

const Ctx = createContext(null);
export const useTheme = () => useContext(Ctx);

// mode : 'systeme' | 'clair' | 'sombre' (mémorisé sur le téléphone)
export function ThemeProvider({ children }) {
  const systeme = useColorScheme();
  const [mode, setMode] = useState('systeme');
  useEffect(() => {
    AsyncStorage.getItem('apparence').then((v) => { if (v) setMode(v); });
  }, []);
  const choisir = (m) => { setMode(m); AsyncStorage.setItem('apparence', m); };
  const estSombre = mode === 'sombre' || (mode === 'systeme' && systeme === 'dark');
  return (
    <Ctx.Provider value={{ c: estSombre ? sombre : clair, sombre: estSombre, mode, choisir }}>
      {children}
    </Ctx.Provider>
  );
}

export const fcfa = (n) => Math.round(n).toLocaleString('fr-FR') + ' FCFA';
export const pct = (v) => (v >= 0 ? '+' : '') + v.toFixed(2).replace('.', ',') + '%';
