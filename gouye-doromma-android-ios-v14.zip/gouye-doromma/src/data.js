// DONNÉES D'EXEMPLE. À remplacer par le flux de fin de journée sous licence BRVM.
export const INDICES = [
  { code: 'BRVM-C', value: 416.07, var: 0.4 },
  { code: 'BRVM-30', value: 196.4, var: 0.32 },
];

// Marché international : indices d'exemple, à titre d'information.
export const INDICES_INTL = [
  { code: 'S&P 500', value: 5800.0, var: 0.3 },
  { code: 'NASDAQ', value: 18400.0, var: 0.5 },
];

// marche : 'UEMOA' | 'INTERNATIONAL'. simulable : peut être planté dans le jardin fictif (BRVM seulement pour l'instant).
// Les valeurs internationales sont en dollars, à titre d'information. L'achat viendra plus tard, avec un partenaire autorisé.
// COURS D'EXEMPLE : à remplacer par des données sous licence (BRVM) et par un fournisseur de données de marché (international).
export const ACTIONS = [
  { ticker: 'SNTS', nom: 'Sonatel', prix: 25000, var: 1.2, per: 11.5, dividende: 1500, marche: 'UEMOA', bourse: 'BRVM', pays: 'Sénégal', devise: 'FCFA', simulable: true, arbre: '🌳 Baobab Numérique' },
  { ticker: 'ORAC', nom: "Orange Côte d'Ivoire", prix: 15375, var: 2.5, per: 9.8, dividende: 1100, marche: 'UEMOA', bourse: 'BRVM', pays: "Côte d'Ivoire", devise: 'FCFA', simulable: true, arbre: '🌴 Palmier Connecté' },
  { ticker: 'BOAS', nom: 'BOA Sénégal', prix: 7180, var: 1.1, per: 7.4, dividende: 520, marche: 'UEMOA', bourse: 'BRVM', pays: 'Sénégal', devise: 'FCFA', simulable: true, arbre: '🌱 Jeune Pousse' },
  { ticker: 'SGBC', nom: 'Société Générale CI', prix: 18500, var: -0.8, per: 8.2, dividende: 1250, marche: 'UEMOA', bourse: 'BRVM', pays: "Côte d'Ivoire", devise: 'FCFA', simulable: true },
  { ticker: 'SLBC', nom: 'Solibra', prix: 80000, var: -2.1, per: 14.1, dividende: 3500, marche: 'UEMOA', bourse: 'BRVM', pays: "Côte d'Ivoire", devise: 'FCFA', simulable: true },
  { ticker: 'ECOC', nom: 'Ecobank Côte d\'Ivoire', prix: 12500, var: 0.6, per: 6.9, dividende: 700, marche: 'UEMOA', bourse: 'BRVM', pays: "Côte d'Ivoire", devise: 'FCFA', simulable: true, arbre: '🌲 Arbre de Croissance' }, // ticker et cours d'exemple, à vérifier
  { ticker: 'AAPL', nom: 'Apple', prix: 230, var: 0.6, per: 30.1, dividende: 1, marche: 'INTERNATIONAL', bourse: 'NASDAQ', pays: 'États-Unis', devise: 'USD', simulable: false },
  { ticker: 'GOOGL', nom: 'Alphabet (Google)', prix: 180, var: -0.4, per: 22.5, dividende: 0.8, marche: 'INTERNATIONAL', bourse: 'NASDAQ', pays: 'États-Unis', devise: 'USD', simulable: false },
  { ticker: 'AMZN', nom: 'Amazon', prix: 200, var: 1.1, per: 36, dividende: 0, marche: 'INTERNATIONAL', bourse: 'NASDAQ', pays: 'États-Unis', devise: 'USD', simulable: false },
  { ticker: 'MSFT', nom: 'Microsoft', prix: 450, var: 0.3, per: 34, dividende: 3.3, marche: 'INTERNATIONAL', bourse: 'NASDAQ', pays: 'États-Unis', devise: 'USD', simulable: false },
  { ticker: 'NVDA', nom: 'NVIDIA', prix: 130, var: -1.2, per: 48, dividende: 0.04, marche: 'INTERNATIONAL', bourse: 'NASDAQ', pays: 'États-Unis', devise: 'USD', simulable: false },
  { ticker: 'TSLA', nom: 'Tesla', prix: 250, var: 2.0, per: 60, dividende: 0, marche: 'INTERNATIONAL', bourse: 'NASDAQ', pays: 'États-Unis', devise: 'USD', simulable: false },
];

// Point d'entrée unique pour les données : brancher ici l'API ou le fichier BRVM.
export async function chargerActions() {
  return ACTIONS;
}

// Historique des cours d'une action sur un nombre de séances.
// EXEMPLE : série fictive reproductible, qui se termine au cours actuel.
// À remplacer par l'historique de la BRVM sous licence (même format : [{ prix }]).
export async function chargerHistorique(ticker, seances) {
  const a = ACTIONS.find((x) => x.ticker === ticker);
  let graine = 0;
  for (const c of ticker) graine = (graine * 31 + c.charCodeAt(0)) % 9973;
  const alea = () => {
    graine = (graine * 9301 + 49297) % 233280;
    return graine / 233280;
  };
  const prix = [a.prix];
  for (let k = 1; k < seances; k++) {
    prix.unshift(Math.max(1, prix[0] * (1 + (alea() - 0.5) * 0.03)));
  }
  return prix.map((p) => ({ prix: p }));
}
