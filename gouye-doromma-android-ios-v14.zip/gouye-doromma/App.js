import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { useFonts } from 'expo-font';
import { Manrope_600SemiBold, Manrope_700Bold } from '@expo-google-fonts/manrope';
import { Inter_400Regular, Inter_500Medium } from '@expo-google-fonts/inter';
import { Lora_500Medium } from '@expo-google-fonts/lora';
import { ThemeProvider, useTheme, police } from './src/theme';
import { StoreProvider } from './src/store';
import { OrdreProvider } from './src/ordre';
import { AuthProvider, useAuth } from './src/auth';
import { VerrouProvider, useVerrou } from './src/verrou';
import MarchesScreen from './src/screens/MarchesScreen';
import FicheScreen from './src/screens/FicheScreen';
import DividendesScreen from './src/screens/DividendesScreen';
import JardinScreen from './src/screens/JardinScreen';
import AcademieScreen from './src/screens/AcademieScreen';
import RecoltesScreen from './src/screens/RecoltesScreen';
import { I18nProvider, useT } from './src/i18n';
import { AcademieProvider } from './src/academie';
import ProfilScreen from './src/screens/ProfilScreen';
import InvestirScreen from './src/screens/InvestirScreen';
import ConnexionScreen from './src/screens/ConnexionScreen';
import BienvenueScreen from './src/screens/BienvenueScreen';
import VerrouScreen from './src/screens/VerrouScreen';
import AccueilScreen from './src/screens/AccueilScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();
const Racine = createNativeStackNavigator();
const icones = { Jardin: 'leaf', Marchés: 'stats-chart', Académie: 'school', Récoltes: 'nutrition', Profil: 'person' };

function MarchesStack() {
  const { c } = useTheme();
  return (
    <Stack.Navigator screenOptions={{ headerTintColor: c.primary, headerTitleStyle: { fontFamily: police.demi, color: c.text } }}>
      <Stack.Screen name="Liste" component={MarchesScreen} options={{ title: 'Marchés' }} />
      <Stack.Screen name="Fiche" component={FicheScreen} options={({ route }) => ({ title: route.params.ticker })} />
      <Stack.Screen name="Dividendes" component={DividendesScreen} options={{ title: 'Calculateur de dividendes' }} />
    </Stack.Navigator>
  );
}

function Onglets() {
  const { c } = useTheme();
  const { t } = useT();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: route.name !== 'Marchés' && route.name !== 'Jardin',
        headerTitleStyle: { fontFamily: police.demi },
        tabBarActiveTintColor: c.primary,
        tabBarInactiveTintColor: c.muted,
        tabBarLabelStyle: { fontFamily: police.demi, fontSize: 11 },
        tabBarIcon: ({ color, size }) => <Ionicons name={icones[route.name]} size={size} color={color} />,
      })}
    >
      <Tab.Screen name="Jardin" component={JardinScreen} options={{ title: t('garden'), tabBarLabel: t('garden') }} />
      <Tab.Screen name="Marchés" component={MarchesStack} options={{ title: t('market'), tabBarLabel: t('market') }} />
      <Tab.Screen name="Académie" component={AcademieScreen} options={{ title: t('academy'), tabBarLabel: t('academy') }} />
      <Tab.Screen name="Récoltes" component={RecoltesScreen} options={{ title: t('harvests'), tabBarLabel: t('harvests') }} />
      <Tab.Screen name="Profil" component={ProfilScreen} options={{ title: t('profile'), tabBarLabel: t('profile') }} />
    </Tab.Navigator>
  );
}

function Ecrans() {
  const { c, sombre } = useTheme();
  const { session, chargement } = useAuth();
  const { verrouille } = useVerrou();
  const uid = session ? session.user.id : null;
  const [accueilVu, setAccueilVu] = useState(null); // null = lecture en cours
  const [bienvenueVue, setBienvenueVue] = useState(null);

  useEffect(() => { AsyncStorage.getItem('accueil_vu').then((v) => setAccueilVu(v === '1')); }, []);
  useEffect(() => {
    if (!uid) { setBienvenueVue(null); return; }
    AsyncStorage.getItem('bienvenue_vue_' + uid).then((v) => setBienvenueVue(v === '1'));
  }, [uid]);
  const terminerAccueil = () => { AsyncStorage.setItem('accueil_vu', '1'); setAccueilVu(true); };
  const terminerBienvenue = () => { AsyncStorage.setItem('bienvenue_vue_' + uid, '1'); setBienvenueVue(true); };

  const base = sombre ? DarkTheme : DefaultTheme;
  const navTheme = { ...base, colors: { ...base.colors, primary: c.primary, background: c.bg, card: c.card, text: c.text, border: c.border } };

  let ecran;
  if (chargement || accueilVu === null || (session && bienvenueVue === null)) {
    ecran = <View style={{ flex: 1, justifyContent: 'center', backgroundColor: c.bg }}><ActivityIndicator color={c.primary} /></View>;
  } else if (!session && !accueilVu) {
    ecran = <AccueilScreen onTermine={terminerAccueil} />;
  } else if (!session) {
    ecran = <ConnexionScreen />;
  } else if (!bienvenueVue) {
    ecran = <BienvenueScreen onTermine={terminerBienvenue} />;
  } else if (verrouille) {
    ecran = <VerrouScreen />;
  } else {
    ecran = (
      <NavigationContainer theme={navTheme}>
        <Racine.Navigator screenOptions={{ headerTintColor: c.primary, headerTitleStyle: { fontFamily: police.demi, color: c.text } }}>
          <Racine.Screen name="Onglets" component={Onglets} options={{ headerShown: false }} />
          <Racine.Screen name="Investir" component={InvestirScreen} options={{ title: 'Investir pour de vrai' }} />
        </Racine.Navigator>
      </NavigationContainer>
    );
  }
  return (<><StatusBar style={sombre ? 'light' : 'dark'} />{ecran}</>);
}

export default function App() {
  const [polices] = useFonts({ Manrope_600SemiBold, Manrope_700Bold, Inter_400Regular, Inter_500Medium, Lora_500Medium });
  if (!polices) return null;
  return (
    <ThemeProvider>
      <I18nProvider>
        <AuthProvider>
          <VerrouProvider>
            <StoreProvider>
              <AcademieProvider>
                <OrdreProvider>
                  <Ecrans />
                </OrdreProvider>
              </AcademieProvider>
            </StoreProvider>
          </VerrouProvider>
        </AuthProvider>
      </I18nProvider>
    </ThemeProvider>
  );
}
