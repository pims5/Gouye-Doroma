-- À exécuter une fois dans Supabase : SQL Editor > New query > Run.
-- Permet à un utilisateur connecté de supprimer son propre compte depuis l'application
-- (obligatoire pour la publication sur l'App Store).
create or replace function public.supprimer_mon_compte()
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  delete from auth.users where id = auth.uid();
end;
$$;

revoke all on function public.supprimer_mon_compte() from public, anon;
grant execute on function public.supprimer_mon_compte() to authenticated;

-- Sauvegarde du portefeuille fictif et des favoris dans le compte.
create table if not exists public.donnees_utilisateur (
  user_id uuid primary key references auth.users(id) on delete cascade,
  cash numeric not null default 1000000,
  positions jsonb not null default '{}'::jsonb,
  favoris jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.donnees_utilisateur enable row level security;

create policy "lecture de ses donnees" on public.donnees_utilisateur
  for select using (auth.uid() = user_id);
create policy "creation de ses donnees" on public.donnees_utilisateur
  for insert with check (auth.uid() = user_id);
create policy "modification de ses donnees" on public.donnees_utilisateur
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
