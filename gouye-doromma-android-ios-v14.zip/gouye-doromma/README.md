# Gouye Doromma - MVP phase 1

Application mobile Android et iOS (un seul code, Expo / React Native).
Information et éducation : pas d'ordres, pas de fonds.

## Lancer en test
1. Installer Node.js (version LTS).
2. Dans ce dossier : `npm install` puis `npx expo install --fix` (aligne les versions).
3. `npx expo start`, puis scanner le QR code avec l'application Expo Go
   (Android et iPhone) ou appuyer sur `a` (émulateur Android) / `i` (simulateur iOS, Mac).

## Fichiers
- App.js : navigation (onglets Marchés, Simulateur, Apprendre + fiche d'une action)
- src/data.js : données d'exemple et point de branchement des vraies données BRVM
- src/store.js : solde fictif, portefeuille, favoris
- src/theme.js : couleurs et formats (FCFA, pourcentages)
- src/screens/ : les 4 écrans
- src/components/ : ligne d'action, mention légale

## Avant de publier
- Remplacer les données d'exemple (src/data.js) par le flux sous licence BRVM.
- Valider le périmètre avec un juriste ou l'AMF-UMOA.
- Publication : compte Google Play Console et compte Apple Developer
  (frais annuels, à vérifier). Build avec EAS Build (`npx eas build`),
  qui permet de produire l'app iOS sans Mac.

## Compte utilisateur (Supabase) : voir aussi « Connexion sans mot de passe » plus bas
Fournisseur : Supabase (offre gratuite pour démarrer, à vérifier).
1. Créer un projet sur supabase.com.
2. Copier `.env.example` en `.env`, puis y coller l'URL du projet et la clé publique (anon),
   visibles dans Project Settings > API.
3. Dans Supabase : SQL Editor, coller le contenu de `supabase/setup.sql`, puis Run
   (active la suppression de compte depuis l'app, exigée par l'App Store).
4. Redémarrer : `npx expo start -c`.

Points à régler avant publication :
- Le lien « mot de passe oublié » ouvre l'URL du site définie dans Supabase (Authentication > URL Configuration).
  Pour réinitialiser directement dans l'app, il faudra ajouter un lien profond (deep link).
- Politique de confidentialité à rédiger, et déclaration à la Commission de protection des
  données personnelles (CDP) à vérifier avec un juriste.
- La connexion par numéro de téléphone (SMS) n'est pas incluse : elle coûte des frais d'envoi de SMS.

## Sauvegarde dans le compte
Le portefeuille fictif et les favoris sont enregistrés dans la table `donnees_utilisateur`
(créée par `supabase/setup.sql`) et retrouvés sur n'importe quel téléphone après connexion.
Chaque utilisateur ne voit que ses propres données (règles RLS). Si le script SQL n'a pas
été exécuté, l'application fonctionne, mais rien n'est sauvegardé.

## Calculateur de dividendes
Accessible depuis la fiche d'une action (bouton « Calculer mes dividendes »).
Il estime les dividendes annuels bruts selon le nombre d'actions et indique combien
d'actions il faut pour atteindre un revenu annuel visé. Basé sur le dernier dividende
connu (src/data.js), avant impôts et frais.

## Écran d'accueil
3 pages affichées au premier lancement (avant la connexion), avec « Passer » et « Commencer ».
Le choix est mémorisé sur le téléphone (clé `accueil_vu`). Pour le revoir en test :
désinstaller l'application ou effacer ses données. Textes modifiables dans
src/screens/AccueilScreen.js.

## Historique de cours (courbe)
Sur la fiche d'une action : courbe sur 1 mois, 3 mois ou 1 an, variation sur la période,
plus bas et plus haut. La courbe utilise react-native-svg (installé par `npx expo install --fix`).
Les données sont fictives : brancher l'historique BRVM dans la fonction `chargerHistorique`
de src/data.js (format attendu : une liste de `{ prix }`, du plus ancien au plus récent).

## Interface (design system)
- `src/theme.js` : jetons (couleurs clair/sombre, espacements, rayons, typographie Sora), `ThemeProvider`
  et `useTheme()`. Apparence Système / Clair / Sombre choisie dans l'onglet Profil.
- `src/ui/` : composants réutilisables : Texte, Carte, Bouton, Chip, Variation, Squelette, EtatVide.
- Règles : cibles tactiles d'au moins 40-48, sens de la variation indiqué par une flèche et un libellé
  d'accessibilité (pas seulement la couleur), états chargement / vide / erreur sur Marchés.
- Nouvelles dépendances : @expo-google-fonts/sora et expo-font (`npx expo install --fix`).

## Le Jardin (concept « Les Anneaux »)
- Premier onglet : un anneau par année de plantation, qui se remplit jusqu'en décembre ; total fictif au centre.
- « Planter » (acheter) et « Vendre » ouvrent une feuille : native sur iPhone (pageSheet), feuille du bas sur Android.
  Depuis la fiche d'une action : bouton « Planter dans mon jardin ».
- Modèle de données : la colonne `positions` contient `{ v: 2, lots: [{ id, ticker, qte, prix, date }] }`.
  L'ancien format `{ ticker: quantité }` est converti automatiquement à la première connexion
  (lots datés d'aujourd'hui, au cours actuel). Aucun changement du script SQL.
- Ventes : premier entré, premier sorti. La performance par année compare le cours actuel au prix de plantation.
- Le simulateur a été remplacé par le Jardin. Nouvelle dépendance : expo-haptics (`npx expo install --fix`).

## Phrases explicatives (concept « Le Fil »)
`src/phrases.js` : une phrase par action (fiche) et une phrase de synthèse du marché (bandeau de l'onglet Marchés),
générées à partir des seules données affichées (variation, dividende, rendement). Aucune cause n'est inventée.
Pour expliquer le « pourquoi » (annonce de dividende, résultats), il faudra une source d'actualités vérifiée.

## Identité : Gouye Doromma, by COUSOUM INC
- Nom : Gouye (baobab, wolof) + Doromma (bague, soninké). Orthographe et prononciation à faire relire par un locuteur ; marque à vérifier auprès de l'OAPI.
- Composants : `src/components/Logo.js` (logo vectoriel), `src/components/Marque.js` (logo, nom en Lora, filet doré, « BY COUSOUM INC »).
- Icônes et écran de démarrage : dossier `assets/` (icon, adaptive-icon, splash-icon, favicon).
- Correction : `userInterfaceStyle` est passé de « light » à « automatic » dans app.json. Avec « light », le thème sombre
  (mode Système) ne pouvait jamais s'activer.
- Identifiants : com.cousoum.gouyedoromma (iOS et Android), à confirmer avant publication.

## Sans ordinateur (Codespaces + EAS)
`eas.json` : profil `preview` (APK Android à partager aux testeurs) et `production`. `demarrer.sh` : installe et lance le test
(`bash demarrer.sh`). Voir le guide « sans ordinateur ».

## Connexion sans mot de passe (v11)
- Un seul champ (email), puis un code à 6 chiffres saisi dans six anneaux. Création de compte et connexion sont le même geste.
  Le code passe par `signInWithOtp` puis `verifyOtp` (Supabase). Plus aucun mot de passe.
- **Réglage Supabase obligatoire** : Authentication > Email Templates. Dans les modèles « Magic Link » ET « Confirm signup »,
  afficher le code avec `{{ .Token }}` (sans cela, l'email contient un lien au lieu du code). Dans Authentication > Providers > Email,
  réduire la durée de validité du code (par exemple 600 secondes).
- Avant le lancement : brancher un expéditeur email dédié (SMTP personnalisé). Le service par défaut est très limité.
- Après le premier code : écran « Ravi de vous voir » (prénom facultatif, activation de Face ID / empreinte).
- Verrou biométrique (`src/verrou.js`) : demandé à l'ouverture et au retour d'arrière-plan selon le délai choisi dans Profil
  (immédiat, 1 minute, 5 minutes). Après 3 échecs : retour au code par email. **Il protège l'application sur ce téléphone ; il n'est
  pas vérifié par le serveur.** Pour de l'argent réel : facteur vérifié côté serveur (passkey ou application d'authentification).
- Dans Expo Go sur iPhone, Face ID n'est pas disponible : le code du téléphone est demandé. Face ID fonctionnera dans la vraie application.
- « Investir pour de vrai » (`src/screens/InvestirScreen.js`) : écran d'information (aucune donnée personnelle collectée) sur les
  informations demandées progressivement : identité, portefeuille mobile money, pièce d'identité au-delà d'un palier à fixer avec la conformité.
- À durcir avant le lancement : jetons de session dans le coffre sécurisé du téléphone (SecureStore) au lieu d'AsyncStorage,
  alerte email à chaque nouvel appareil.

## Connexion par numéro de téléphone (v12, remplace l'email)
- Un seul champ : le numéro (Sénégal +221 par défaut, pays de l'UEMOA au choix). Code à 6 chiffres reçu par SMS (ou WhatsApp), saisi dans les six anneaux.
  Les anciens comptes créés avec un email (v10 et v11) ne peuvent plus se connecter : sans importance avant le lancement.
- **Réglage Supabase obligatoire** : Authentication > Providers > Phone : activer, puis configurer un fournisseur d'envoi
  (Twilio Verify pour commencer) ou le « Send SMS Hook » pour un fournisseur local. Message du code, par exemple :
  « Votre code Gouye Doromma : {{ .Code }} ».
- **Coût** : un SMS vers le Sénégal coûte de l'ordre de 0,2 à 0,55 $ chez Twilio (tarifs publics vus en octobre 2026, à revérifier), soit
  environ 120 à 330 FCFA par code. WhatsApp via Twilio est bien moins cher mais exige un compte WhatsApp Business validé par Meta
  (`EXPO_PUBLIC_CANAL_CODE=whatsapp`, fournisseur Twilio uniquement).
- **Fraude aux SMS (« SMS pumping »)** : limiter les pays autorisés chez le fournisseur, limiter la fréquence des demandes,
  activer la protection contre la fraude de Twilio Verify. Tester la livraison sur Orange, Free et Expresso.
- **Limites du numéro comme identité** : changement ou perte de numéro, numéro réattribué, échange de carte SIM. Prévoir plus tard
  un second moyen de récupération (email facultatif dans Profil).
- Longueurs de numéros par pays (src/securite.js) à confirmer avant le lancement. Le verrou Face ID reste inchangé.

## Marchés UEMOA et international (v13)
- Onglet Marchés : deux marchés, « UEMOA » (BRVM) et « International » (Apple, Alphabet/Google, Amazon, Microsoft, NVIDIA, Tesla en exemple).
  Chaque marché a son indice, sa phrase de synthèse, sa recherche et ses filtres.
- International = **information seulement** : cours en dollars avec équivalent en FCFA (taux d'exemple dans `src/devises.js`), pas de bouton
  Planter, message « Achat bientôt disponible ». Le jardin fictif et le calculateur de dividendes ne proposent que les valeurs `simulable: true` (BRVM).
- Données : tous les cours de `src/data.js` sont des exemples. À prévoir : fournisseur de données de marché avec droit de redistribution
  pour l'international (cours différés), taux de change réel, licence BRVM.
- Achat futur : partenaire autorisé (courtier), réglementation des changes de l'UEMOA et règles de l'AMF-UMOA à valider avec la conformité.
- Signature « BY COUSOUM INC » : uniquement sur l'écran d'accueil (Jardin), via `src/components/Signature.js`. Retirée de la connexion et de Profil.

## Alignement sur le document produit ANNEAUX (v14, première phase)
Le nom de l'application reste **Gouye Doromma** (choisi dans cette conversation). Le reste suit le document produit.
- **ADS (Annular Design System)** : palette (Green900 #145A4B, Green300 #A8D5B2, Harvest500 #F6A53A, Neutral50 #F7F6F2, Navy900 #152238 ;
  mode sombre : fond #0B1210, surface #15211C, GreenGlow #67D39A, Luxury #B88C4A), polices Manrope (titres) et Inter (texte).
  En clair, l'or du texte reste #8C6A2F (le Luxury #B88C4A est trop pâle sur fond clair pour du petit texte).
- **Navigation à 5 onglets** : Jardin, Marchés, Académie, Récoltes, Profil. Les Objectifs ne sont pas encore construits.
- **Wealth Ring** (`src/components/AnneauxPatrimoine.js`) : 4 anneaux, Capital, Croissance, Récolte, Connaissance, tailles S 120, M 180, L 240, XL 320.
  Repères d'affichage : Croissance pleine à +20 %, Récolte pleine à 10 % de rendement estimé (`src/jardin.js`), à valider avec la marque et la conformité.
- **Marchés** : noms d'arbres (Baobab Numérique pour Sonatel, Palmier Connecté pour Orange CI, Jeune Pousse pour BOA, Arbre de Croissance pour Ecobank).
  Le cours et le ticker de l'Ecobank de `src/data.js` sont des exemples à vérifier.
- **Récoltes** : dividendes vus comme des récoltes. Estimation annuelle seulement ; les dates et l'historique réels viendront avec les données sous licence.
- **Académie** : 5 modules, 10 leçons courtes (`src/academieData.js`), progression mémorisée sur le téléphone. Textes à relire par la conformité.
- **i18n** : `src/locales/fr.json`, `src/locales/en.json`, `src/i18n.js`. Seuls les nouveaux écrans et les onglets sont traduits ; le reste de l'interface est
  encore en français (traduction complète = phase suivante). Langue au choix dans Profil.
- Phase suivante : Objectifs, niveaux et badges, animations de plantation et de récolte, traduction complète, Figma.
- Nouvelles dépendances : @expo-google-fonts/manrope, @expo-google-fonts/inter (remplacent Sora). `npx expo install --fix`.
